import React from 'react';

const exports = {};

// Player views must be extended.
// It does not have its own Wrapper view.

exports.GetVal = class extends React.Component {
  render() {
    const { parent, playable, val } = this.props;
    return (
      <div>
        <h2>Foodbank found</h2>
        <p>We have found a drop-off center at Kajang, would you like to use FeeD delivery?</p>
        <button
          disabled={!playable}
          onClick={() => parent.setVal('1')}
        >Yes</button>
        <button
          disabled={!playable}
          onClick={() => parent.setVal('0')}
        >No, I will drop off myself.</button>
      </div>
    );
  }
}
exports.GetGuessVal = class extends React.Component {
  render() {
    const { parent, playable, val } = this.props;
    return (
      <div>
        <p>Rider found! Will arrive in 5 min..</p>
        <button
          disabled={!playable}
          onClick={() => parent.setGuessVal(0)}
        >OK</button>
      </div>
    );
  }
}

exports.WaitingForResults = class extends React.Component {
  render() {
    return (
      <div>
        Rider is delivering your food...
      </div>
    );
  }
}

exports.Done = class extends React.Component {
  render() {
    const { outcome } = this.props;
    return (
      <div>
        Thank you.  {outcome}
        <br />
      </div>
    );
  }
}

exports.Timeout = class extends React.Component {
  render() {
    return (
      <div>
        There's been a timeout. (Someone took too long.)
      </div>
    );
  }
}

export default exports;
