import React from 'react';
import PlayerViews from './PlayerViews.js';

const exports = { ...PlayerViews };

const sleep = (milliseconds) => new Promise(resolve => setTimeout(resolve, milliseconds));

exports.Wrapper = class extends React.Component {
  render() {
    const { content } = this.props;
    return (
      <div className="Deployer">
        <h2>Marketplace</h2>
        {content}
      </div>
    );
  }
}

exports.SetWager = class extends React.Component {
  render() {
    const { parent, defaultWager, standardUnit } = this.props;
    const wager = (this.state || {}).wager || defaultWager;
    return (
      <div>
        <div class="sell-container">
          <h2>Sell your item</h2>
          <p>1. Describe.</p>
          <label>Item Name: <input type="text" value="Tomato" /></label><br /><br />
          <label>Item Desc: <input type="text" value="Buy from econsave" /></label><br /><br />
          <label>Price:
            <input
              type='number'
              placeholder={defaultWager}
              onChange={(e) => this.setState({ wager: e.currentTarget.value })}
            /> {standardUnit}</label>
          <br /><sm>* 2% processing fee will be charged.</sm>
          <br />
          <label>Qty <input type="number" value="5" /></label><br />

          <p>2. What is your product category?</p>
          <label>
            <input type="radio" name="category" value="veggies" />veggies
          </label>
          <label>
            <input type="radio" name="category" value="meat" />fresh meat
          </label>
          <label>
            <input type="radio" name="category" value="grocers" />grocers
          </label>
          <label>
            <input type="radio" name="category" value="cooked" />cooked food
          </label>
          <p>3. Scan freshness.</p>
          <button
          >Using Phone</button>
          <button
          >Using IoT Detector</button><br /><br />
          <button class="submit-btn"
            onClick={() => parent.setWager(wager)}
          >Sell Now</button>
        </div>
      </div>
    );
  }
}

exports.Deploy = class extends React.Component {
  render() {
    const { parent, wager, standardUnit } = this.props;
    return (
      <div>
        Your food will be submitted to the marketplace. <strong>{wager}</strong> {standardUnit}
        <br />
        <button
          onClick={() => parent.deploy()}
        >Submit</button>
      </div>
    );
  }
}

exports.Deploying = class extends React.Component {
  render() {
    return (
      <div>Submitting your request... please wait.</div>
    );
  }
}

exports.WaitingForAttacher = class extends React.Component {
  async copyToClipboard(button) {
    const { ctcInfoStr } = this.props;
    navigator.clipboard.writeText(ctcInfoStr);
    const origInnerHTML = button.innerHTML;
    button.innerHTML = 'Copied!';
    button.disabled = true;
    await sleep(1000);
    button.innerHTML = origInnerHTML;
    button.disabled = false;
  }

  render() {
    const { ctcInfoStr } = this.props;
    return (
      <div>
        <h2>Notification: </h2>
        Ali made a purchase request from you.
        <pre className='ContractInfo'>
          {ctcInfoStr}
        </pre>
        <button
          onClick={(e) => this.copyToClipboard(e.currentTarget)}
        >Copy to clipboard</button>
      </div>
    )
  }
}

export default exports;
