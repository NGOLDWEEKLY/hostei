import React from 'react';
import PlayerViews from './PlayerViews.js';

const exports = { ...PlayerViews };

exports.Wrapper = class extends React.Component {
  render() {
    const { content } = this.props;
    return (
      <div className="Attacher">
        <h2>Marketplace</h2>
        {content}
      </div>
    );
  }
}

exports.Attach = class extends React.Component {
  render() {
    const { parent } = this.props;
    const { ctcInfoStr } = this.state || {};
    return (
      <div>
        Your cart:
        <div>
          <p>Tomato</p>
          <p>Price: 1 ALGO &nbsp;&nbsp; Qty: 1</p>
        </div>
        <br />
        Fetching contract info, or attach manually.
        <br />
        <textarea spellCheck="false"
          className='ContractInfo'
          onChange={(e) => this.setState({ ctcInfoStr: e.currentTarget.value })}
          placeholder='{}'
        />
        <br />
        <button class="submit-btn"
          disabled={!ctcInfoStr}
          onClick={() => parent.attach(ctcInfoStr)}
        >Checkout</button>
      </div>
    );
  }
}

exports.Attaching = class extends React.Component {
  render() {
    return (
      <div>
        Attaching smart contract, please wait...
      </div>
    );
  }
}

exports.AcceptTerms = class extends React.Component {
  render() {
    const { wager, standardUnit, parent } = this.props;
    const { disabled } = this.state || {};
    return (
      <div>
        Tomato 1pc<br />
        Pay using FDC Wallet
        <br /> Total Payment: {wager} {standardUnit}
        <br />
        <button class="submit-btn"
          disabled={disabled}
          onClick={() => {
            this.setState({ disabled: true });
            parent.termsAccepted();
          }}
        >Pay Now</button>
      </div>
    );
  }
}

exports.WaitingForTurn = class extends React.Component {
  render() {
    return (
      <div>
        Waiting for seller to ship your order...
      </div>
    );
  }
}

export default exports;
