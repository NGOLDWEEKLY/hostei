var x= setInterval(checkheader,10);


  function scroller(){
            var divFirst = document.getElementById("nav");
   var scroll= divFirst.scrollTop;
   var height=  divFirst.scrollHeight;
var media =window.innerWidth;
   var y= window.pageYOffset;
   if(media >=900){
   if(y<=10){
          document.getElementsByClassName('holder')[0].style.top ="0px";
    document.getElementById('logo-detail').style.display ="block";
    document.getElementsByClassName('svg-holder')[0].style.display ="block";
    
    document.getElementById('bar-container-mobile').innerHTML ="";
    document.getElementById('circle').style.width ="200px";
    document.getElementById('circle').style.height ="200px";
    document.getElementById('footer').style.height ="10px";
    document.getElementsByClassName('logo-title')[0].style.marginTop ="0px";

   }
   
   else {
           document.getElementsByClassName('holder')[0].style.top ="-100px";
    document.getElementById('logo-detail').style.display ="none";
    
    document.getElementById('bar-container-mobile').innerHTML ="";
    
    document.getElementsByClassName('svg-holder')[0].style.display ="none";
    document.getElementById('circle').style.width ="5px";
    document.getElementById('circle').style.height ="5px";
    document.getElementById('footer').style.height ="50px";
    document.getElementsByClassName('logo-title')[0].style.marginTop ="25px";

   }} else if(media < 900){
         if(y<=600){
          document.getElementsByClassName('holder')[0].style.top ="-50px";
              document.getElementById('logo-detail').style.display ="none";
              
    document.getElementsByClassName('svg-holder')[0].style.display ="none";
    document.getElementById('circle').style.width ="170px";
    document.getElementById('circle').style.height ="170px";
    document.getElementById('bar-container-mobile').style.display ="none";
    document.getElementById('footer').style.height ="0";
    document.getElementsByClassName('logo-title')[0].style.marginTop ="0px";

   }
   
   else {
           document.getElementsByClassName('holder')[0].style.top ="-100px";
        document.getElementById('logo-detail').style.display ="none";
    document.getElementsByClassName('svg-holder')[0].style.display ="none";
    document.getElementById('circle').style.width ="5px";
    document.getElementById('circle').style.height ="5px";
    document.getElementById('footer').style.height ="10px";
    
    document.getElementById('bar-container-mobile').style.display ="block";
    document.getElementsByClassName('logo-title')[0].style.marginTop ="25px";

   }
       
       
   }
}


function checkheader(){

var y= window.pageYOffset ;
var i;
var d = document.getElementsByClassName('ul');

for (i = 0; i < d.length; i++) { 
   d[i].style.fontWeight ="normal";
   d[i].style.color ="#8d8d8d";
}
if(y>2610){
document.getElementsByClassName('ul')[3].style.fontWeight="bold";
document.getElementById('anchor5').style.display="flex";


document.getElementsByClassName('ul')[3].style.color="#a0a0a0";
}else if(y>1980){
document.getElementsByClassName('ul')[2].style.fontWeight="bold";
document.getElementById('anchor4').style.display="flex";


document.getElementsByClassName('ul')[2].style.color="#a0a0a0";


    
    
}else if(y>1270){
document.getElementsByClassName('ul')[1].style.fontWeight="bold";

document.getElementById('anchor3').style.display="flex";


  

document.getElementsByClassName('ul')[2].style.color="#a0a0a0";
}else if(y>630){
document.getElementsByClassName('ul')[0].style.fontWeight="bold";
document.getElementById('anchor2').style.display="flex";


document.getElementsByClassName('ul')[2].style.color="#a0a0a0";
}
else if(y>0){
    return;
}
}
window.onload = function(){
          var x= getCookie("ei_token");
        if (x !== '') {
          
            window.location.replace('http://www.hostei.com/user');
    
}  
    
        document.getElementById('anchor2').style.display="none";
document.getElementById('anchor3').style.display="none";
document.getElementById('anchor4').style.display="none";
document.getElementById('anchor5').style.display="none";
}


    
    
           var elmt= ["#part1",".nav-container","#part2","#anchor2","#part3","#anchor3","#part4","#anchor4","#part5","#anchor6","#part6"];
           var i =0;


$(document).ready(function(){
    scroller();
    

                $('#select').on('click', function(){
var parts = window.location.href.split('/');
var al = parts.pop() || parts.pop();  
if(al == 'zh-cn'){window.location.replace('http://www.hostei.com/en-us/');}
if(al == 'en-us'){window.location.replace('http://www.hostei.com/zh-cn/');}
});



                $('#part6').on('click', function(){
window.location.replace('http://www.hostei.com/EILogin');
});    
$('#social-fb-signup').on('click', function(){
window.location.replace('http://www.hostei.com/EILogin/social-zone');
});    
                $('#btn1').on('click', function(){
    document.getElementById('audio').play();
$('html, body').animate({scrollTop: $("#part2").offset().top- 80}, 'slow');
i += 2;
});    

$('#btn2').on('click', function(){
$('html, body').animate({scrollTop: $("#part3").offset().top- 80}, 'slow');
i += 1;
    
});
$('#btn3').on('click', function(){
$('html, body').animate({scrollTop: $("#part4").offset().top- 80}, 'slow');
i += 1;
});
$('#btn4').on('click', function(){
$('html, body').animate({scrollTop: $("#part5").offset().top- 80}, 'slow');
i += 1;
});

$('#btn5').on('click', function(){

$(".holder").hide();
 $(".footer").animate({right: '0', bottom: '0', width: 'unset', height: '100%'}, 1);
 $("#login-pg").show();
});

 $('#tbtn1').on('click', function(){
$('html, body').animate({scrollTop: $("#part2").offset().top- 80}, 'slow');
i += 2;
});
 $('#tbtn2').on('click', function(){
$('html, body').animate({scrollTop: $("#part3").offset().top- 80}, 'slow');
i += 1;
});
 $('#tbtn3').on('click', function(){
$('html, body').animate({scrollTop: $("#part4").offset().top- 80}, 'slow');
i += 1;
});
 $('#tbtn4').on('click', function(){
$('html, body').animate({scrollTop: $("#part5").offset().top- 80}, 'slow');
i += 1;
});

$(window).scroll(function() {
   if($(window).scrollTop() + $(window).height() >= $(document).height() - 65 ) {

$(".holder").hide();
 $(".footer").animate({right: '0', bottom: '0', width: 'unset', height: '100%'}, 1);
 $("#login-pg").show();
 
   }else{
       $(".holder").show();
 $("#login-pg").hide();
   }
});
    
    
    
});              




        $(document).keydown(function(e){
       if(e.which==34 || e.which==40){
 
         if(i>9){i==10;}else if(1<=9){
       i++;     $('html, body').animate({scrollTop: $( elmt[i]).offset().top}, 'slow'); 
}
     
 }
       if( e.which==33 || e.which==38){

     if(i<=0){i===0;}else if(1>0){
       i--;     $('html, body').animate({scrollTop: $( elmt[i]).offset().top}, 'slow'); 
}

}
   });


   
  