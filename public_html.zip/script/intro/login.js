
function checker() {
    
    var stre = document.getElementById('ei-user-id');
 var x = stre.validity.valid;
    var y =stre.value.includes('@'); 
    
      if(x === true && y === true){

 if (window.XMLHttpRequest) {
     
            xmlhttp = new XMLHttpRequest();
        } else {
            
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }


        xmlhttp.open("POST","../../EILogin/key_up",true);
        
 xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xmlhttp.send("md=" + stre);

             xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {

if(this.responseText == "0"){document.getElementById('signup-btn').value = 'Sign in'}
else if(this.responseText == "1"){stre.style.background = '#c5ffbe';
  
}
}
        };     
        

        
    }
}

var deter_o ='';
function char_log_temp() {
    
    var stre = document.getElementById('ei-user-id');
    var strp = document.getElementById('ei-password');
 var x = stre.validity.valid;
    var y =stre.value.includes('@'); 
    var z = strp.value;
    if(stre.value === ''){deterner();}
    if(z < 8){
        if(deter_o === ''){
          document.getElementsByClassName('password')[0].insertAdjacentHTML("afterend","<span id='warn2' style='    color: red;    text-align: center;    font-size: 15px;z-index: 9999;    line-height: 27px;'>Your password should at least have 8 character.</span>");
            deter_o += 'notnull';
            
        }
            else{
                
$('#warn2').show();
            }
            return;
    }
      if(x === true && y === true ){

 if (window.XMLHttpRequest) {
     
            xmlhttp = new XMLHttpRequest();
        } else {
            
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }


        xmlhttp.open("POST","../../EILogin/temp/",true);
        
 xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xmlhttp.send("md=" + stre.value + "&p=" + strp.value );

             xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {

if (this.responseText === "2.0bx1y"){
    window.location.replace("../../EILogin");
    
}
}
        };     
        

        
    }
}
    var deter = '';
function deterner(){

    var stre = document.getElementById('ei-user-id');
    if(stre.value == ""){
        if(deter == ''){
        document.getElementsByClassName('user')[0].insertAdjacentHTML("afterend","<span id='warn' style='    color: red;    text-align: center;    font-size: 15px;z-index: 9999;    line-height: 27px;'>This is a required field.</span>");
            deter += 'notnull';
        }
        else{
$('#warn').show();

            
        }
 
    } else if(stre.value !== ""){
         var strp = document.getElementById('ei-password');
        var s_x = strp.value.match(/[a-z]/i);
                var s_y = strp.value.match(/[0-9]/i);
                if((s_x) || (s_y)){
                    if((s_x) && (s_y)){
                        if(strp.value.length > 8){
                            strp.style.background ="#c5ffbe";
                        }
                        else{
                             strp.style.background ="#f9ffbe";
                            
                        }
                    }
                    else{
                         strp.style.background ="#ffbebf";
                    }
                }
    }
    
    
}


$(document).ready(function(){
    
        $('#ei-user-id').keydown(function(){

    var stre = document.getElementById('ei-user-id');
   stre.style.background = '#fff';
  checker();
    if(deter === "notnull"){ $('#warn').hide();}
   });
        $('#ei-password').keydown(function(){
  
    var stre = document.getElementById('ei-password');
   stre.style.background = '#fff';
 deterner();
     if(deter_o === "notnull"){ $('#warn2').hide();}
   });
        
        $('#signup-btn').click(function(){
  char_log_temp();
   });


    
});              







   
  