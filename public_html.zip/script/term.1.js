  window.onload = function() {
            var x= getCookie("ei_token");
            var y=window.location.href;
            var str1 = 'http://www.hostei.com/en-us';
            var str2 = 'http://www.hostei.com/zh-cn';
        if (x === '' && (y !== str1 || y !== str2)) {
          
           window.location.href = 'http://www.hostei.com';


}  
    }
  