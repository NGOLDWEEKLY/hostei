function setter(){
    if(uid !== '' && un !== ''){
    document.getElementsByClassName('user-head-profile')[0].style.backgroundImage = "url('https://graph.facebook.com/"+uid+"/picture?width=300&height=300')";
        document.getElementsByClassName('user-head-profile')[0].style.backgroundSize = "100%";
            document.getElementsByClassName('user-head-profile')[0].style.backgroundRepeat = "no-repeat";
            document.getElementsByClassName('user-head-profile')[0].style.backgroundPosition = "center";
            var ch = un;
var unn = ch.split(" ");
var acun = unn[0];
document.getElementsByClassName('user-name-text')[0].innerHTML =  acun ;
document.getElementsByClassName('user-name-text')[1].innerHTML =  acun ;


clearInterval(set_er);


    }
}
var set_er = setInterval(setter, 30);