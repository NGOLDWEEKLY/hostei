console.log(document.getElementById("user-detail"));
document.getElementById("user-detail").addEventListener("click", function(){char_log_off();document.cookie = "ei_token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    location.reload();
});

function char_log_off() {
       
FB.logout(function(response) {

});

   
   
}
