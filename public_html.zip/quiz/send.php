
    <?php
// Get connection
$servername = "localhost";
$username = "id2188560_ngold";
$password = "qwertyqwerty";
$dbname = "id2188560_chatroom";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    echo "Connection failed. Please try again later.";
    echo "<br>";
}
$user = $_POST['username'];
$chat = $_POST['mark'];
$sql = "INSERT INTO Marks (username, mark)
VALUES ('$user','$chat')";

if(mysqli_query($conn, $sql)) {
 
}else{
    echo "Error: " . $sqli . "<br>" . mysqli_error($conn);
    
}

mysqli_close($conn); 

?><meta http-equiv="refresh" content="0; url=http://www.hostei.com/quiz">
<body><style>body {
font-family: Microsoft YaHei;
background:#3ebf6d;
user-select: none;
-moz-user-select: none;
cursor: default;
transition: ease 2s;

}</style></body>