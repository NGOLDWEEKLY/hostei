
    <?php
// Get connection
$servername = "localhost";
$username = "id2188560_ngold";
$password = "qwertyqwerty";
$dbname = "id2188560_chatroom";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    echo "Connection failed. Please try again later.";
    echo "<br>";
}
$name = $_POST['name'];
$time = $_POST['time'];
$one = $_POST['one'];
$two = $_POST['two'];
$three = $_POST['three'];
$four = $_POST['four'];
$five = $_POST['five'];
$six = $_POST['six'];
$seven = $_POST['seven'];
$eight = $_POST['eight'];
$nine = $_POST['nine'];
$ten = $_POST['ten'];
$sql = "INSERT INTO Quiz (time,name,one,two,three,four,five,six,seven,eight,nine,ten)
VALUES ('$one','$two','$three','$four','$five','$six','$seven','$eight','$nine','$ten')";

if(mysqli_query($conn, $sql)) {
 
}else{
    echo "Error: " . $sqli . "<br>" . mysqli_error($conn);
    
}

mysqli_close($conn); 

?><meta http-equiv="refresh" content="0; url=http://www.hostei.com/quiz/uec">
<body><style>body {
font-family: Microsoft YaHei;
background:#3ebf6d;
user-select: none;
-moz-user-select: none;
cursor: default;
transition: ease 2s;

}</style></body>