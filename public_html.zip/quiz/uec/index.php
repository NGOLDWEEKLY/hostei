<script>
var a = "<?php 
date_default_timezone_set('	Asia/Kuala_Lumpur'); // CDT

$current_date = date('d/m/Y');
$current_hour = date('h');
$current_sec = date('s');
$current_min = date('m');
if ($current_date != "23/10/2017") {
    echo "na";
}
elseif( $current_hour == 12){
    echo "a";
    
}
elseif( $current_hour != 12){
    echo"na";
    
}
?>;
if(a == "a"){
    
    
    alert();
}
else if(a == "na"){
    
    
    
    
}
</script>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta property="og:url" content="http://www.hostei.com/quiz" />
<meta property="og:type" content="article" />
<meta property="og:title" content="颠覆学霸思维，学渣不再低头！" />
<meta property="og:description" content="统考死亡考卷测试" />
<meta property="og:image" content="data/meta.jpg" />
  <link rel="icon" href="data/favicon.png" type="image/png" sizes="16x16">
<title>颠覆学霸思维，学渣不再低头！</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js">
</script>
<script>
</script>
<script>
    $(document).keydown(function(event){
    if(event.keyCode==123  ){
        return false;
    }
    else if (event.ctrlKey && event.shiftKey && event.keyCode==73){        
             return false;
    }
});

$(document).on("contextmenu",function(e){        
   e.preventDefault();
});

    
</script>
<style>
body {
font-family: Microsoft YaHei;
background:#3ebf6d;
user-select: none;
-moz-user-select: none;
cursor: default;
transition: ease 2s;

}
@keyframes fade {
0%{opacity:0}
100%{opacity:1}

}
.title {
text-align:center;
animation: fade 0.2s;
}

.logo {
font-weight: bold;
font-size: 35px;
color: #FFF6A5;
margin-left:10px;
margin-right:10px;
margin-top:150px;
letter-spacing: 3px;
font-family: Microsoft YaHei;
animation: fade 0.2s;
}
.logodetail {
margin-top:-20px;
font-family: 'Pacifico', cursive;
color: #FFFBCA;
    letter-spacing: 2px;
animation: fade 0.2s;
font-size:18px;
}
.game {
display:none;	

}
.button {    margin: auto;
    text-align: center;
animation: pop 0.5s;

    margin-top: 40px;
padding: 10px 10px;

}
.urname {
margin-top:60px;
text-align:center;
animation: scroll 0.5s;
}
@keyframes scroll {
0%{margin-top:180px;opacity:0.1;}
99%{margin-top:55px;opacity:1.0;}
100%{margin-top:60px;}
}
@keyframes scroll2 {
0%{margin-top:180px;opacity:0.1;}
99%{margin-top:125px;opacity:1.0;}
100%{margin-top:130px;}
}
input{
    width: 220px;
    height: 50px;
    border-style:none;padding-right: 20px;
    background:white;
    text-align:center;
    font-size:18px;
}
button {
    text-decoration: none;
    border-style: solid;
    width: 130px;
    height: 50px;
    border-color: white;
    color: white;
    background: none;
    font-family: Microsoft YaHei;
    letter-spacing:3px;
    font-size: 20px;
    cursor: pointer;
transition: ease 0.3s;
}

label {
    padding: 10px 0px;
    margin: auto;
max-width: 300px;
    width: 70%;
cursor:pointer;
    border-width: 2px;
    display: block;
    text-align: center;
    border-color: block;
    margin-top: -15px;
    font-size: 18px;
    border-style: solid;
    color: #FFFBCA;
transition: ease 0.3s;

}
button:hover {

background:white;
opacity:0.8;
color:#3ebf6d;
}
label:hover {

background:white;
opacity:0.8;
color:#3ebf6d;
}
.pg2{
	
	display:none;
transition:ease 1s;}
.box1 {
margin:auto;
padding: 3px 3px;
margin-top: 10px;
width: 280px;
min-width: 200px;
max-width: 300px;
text-align:center;
height: 300px;
background:#FFF6A5;
font-weight:bold;
color:#3ebf6d;
letter-spacing: 2px;
font-size: 25px;
transition:linear 0.3s;
animation:scroll 0.3s;
}

.box2 {
	margin-top: -15px;
	}
.plate {
	    display: inline-flex;
font-size:10px;
overflow-y: scroll;
margin-top:10px;
height:180px;
    margin: auto;
	}
	
.row {
	margin: auto;
z-index: 111;
	}
.mooncake {
cursor:pointer;
border-radius: 100px;
width: 38px;
height: 38px;
background: #ffffff;
margin:5px 5px;
padding: 10px 10px;
transition: ease 0.2s;
border-color:#FFFBCA;
border-style:solid;
border-width:3px;
}

.hli {

    border:2px solid blue;
    
}

.colours {
	display:none;
	
	}
.question {
	display:none;
animation:scroll 0.3s;
	}
	
	  select {
  padding:10px 100px;
  border-style:none;
  cursor:pointer;
  
  }

</style>
<script>
	    var mark=getCookie("mark");
window.onload = function(){
	
	    var user=getCookie("username");
	    if (user != "") {
document.getElementById('pg1').innerHTML="";
document.getElementById('pg13').style.display="block";
			
 window.onbeforeunload = false;
	    var mark=getCookie("mark");
 num = mark;
if(num >175) {var range = '恭喜大败学霸！';}
else if(num >150) {var range = '恭喜大败学霸！';}
else if(num >125) {var range = '细心的人才是王道！';}
else if(num >100) {var range = '蓄势待发，打败学霸！';}
else if(num >75) {var range = '有前途！再接再厉！';}
else if(num >50) {var range = '学霸，看来你太草率了！';}
else if(num >25) {var range = '自以为是的学霸！';}
else if(num >0) {var range = '自以为是的学霸！';}
else if(num =0) {var range = '自以为是的学霸！';}

		document.getElementsByTagName('body')[0].style.background = '#3e94bf';	
		document.getElementById('img').innerHTML= Math.round((num)/25) + 'A' ;
document.getElementById('topic').innerHTML= range;
	   

			
			}

	else{
	    
		document.getElementById('pg1').style.display = "block";
	    
	}
	}
    window.onbeforeunload = function(){
   return "Do you really want to leave our brilliant application?";
   //if we return nothing here (just calling return;) then there will be no pop-up question at all
   //return;
    }


function setCookie(cname,cvalue,exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}




function next() {
	    var user=getCookie("username");
    if (user != "" ) {
        
		document.getElementById('name').innerHTML = user;
    } else {
       user = document.getElementsByTagName("input")[0].value;
       if (user != "" && user != null) {
           setCookie("username", user, 30);
		document.getElementById('pg1').style.display = "none";
		   
		document.getElementById('name').innerHTML = user;
		document.getElementById('pg2').style.display = "block";
		document.getElementById('pg13').style.display = "none";
       }
	   
    }
}
function nextt() {
	    var user=getCookie("username");
	    
    if (user != "") {
			document.getElementById('name').innerHTML = user;
			
 window.onbeforeunload = false;
       if (user != "" && user != null) {
           setCookie("username", user, 30);
		document.getElementById('pg1').style.display = "none";
		   
		document.getElementsByTagName('body')[0].style.background = '#3ebf6d';	
		document.getElementById('pg2').style.display = "block";
		document.getElementById('pg13').style.display = "none";
		document.getElementById('name').innerHTML = user;
       }
    
	} else {
       user = document.getElementsByTagName("input")[0].value;
       if (user != "" && user != null) {
           setCookie("username", user, 30);
		document.getElementById('pg1').style.display = "none";
		   
		document.getElementsByTagName('body')[0].style.background = '#3ebf6d';	
		document.getElementById('pg2').style.display = "block";
		document.getElementById('pg13').style.display = "none";
		document.getElementById('name').innerHTML = user;
       }
    }
}
function start(){
	    var mark=getCookie("mark");
	if(mark >0) {
		
		document.getElementById('pg13').style.display = "block";
	
		document.getElementsByTagName('body')[0].style.background = '#3e94bf';	
		document.getElementById('pg2').style.display = "none";
		} else{
		document.getElementById('pg3').style.display = 'block';		
		document.getElementById('pg2').style.display = 'none';	}
}
</script>
</head>
<body>

<div class="pg1" id="pg1" style="display:none;"><div class="title"><p class="logo">颠覆学霸思维，<br>学渣不再低头！</p><p class="logodetail" >振奋人心的死亡考卷测试。</p>
</div>
<div class="urname">

<input id="namea" type="text" placeholder="&nbsp;&nbsp;输入你的名字" required autofocus/>
<div class="button" id="button" style="margin-top:10px;"><button onclick="next()">继续</button></div>
</div></div>
<div id="pg2" class="pg2">
<p style="margin-top: 100px;text-align:center;font-size:20px;letter-spacing:3px;
color:#FFFBCA;font-weight:bold;">亲爱的<span id="name">朋友</span>：</p>
<div id="box1" class="box1"><p style="
    margin-bottom: 40px;
">了解服务条款</p>
<div id="box2" class="box2">
<div class="plate">
<p style="padding: 10px 40px;">
您在使用本站提供的各项服务（包括心理测试）之前，必须了解本站的服务条款。所有题目都是可能受到版权和著作权维护的。任何作弊行为将会受到惩治。拷贝或使用本站提供的服务将可能不会收到法律的追究；您一旦使用此项服务，即视为您已经了解并完全同意本服务条款及额外条款的各项内容。
在还未开始作答之前，希望你能了解自己的能力，避免因为分数受到打击。且一题10分，答错1题倒加10分，答对一题扣20分。<br><br>Understand the terms of service<br>
Before you use the services provided by this site (including psychological tests), you must understand the terms of service of this site. All topics are subject to copyright and copyright protection. Any cheating will be punished. Copy or use the services provided by this site will not be subject to legal action; once you use this service, you are aware and fully agree with the terms of service and additional terms of the content.
Before you start answering, hope that you can understand your ability to avoid being hit because of the score. And a question of 10 points, the wrong one question plus 10 points, 20 points on a buckle.</p>

</div>


</div>

</div>

<div class="button" id="button2" style="margin-top: 10px;"><button onclick="start()">继续</button></div>
</div>
<form method="post" class="juec" id="juec" name="juec" action="send.php" >
<div id="questions">
<script>
function qa(){
		document.getElementById('pg4').style.display = 'block';		
		document.getElementById('pg3').style.display = 'none';	
}	
function qb(){
		document.getElementById('pg5').style.display = 'block';		
		document.getElementById('pg4').style.display = 'none';	
}	
function qc(){
		document.getElementById('pg6').style.display = 'block';		
		document.getElementById('pg5').style.display = 'none';	
}	
function qd(){
		document.getElementById('pg7').style.display = 'block';		
		document.getElementById('pg6').style.display = 'none';	
}	
function qe(){
		document.getElementById('pg8').style.display = 'block';		
		document.getElementById('pg7').style.display = 'none';	
}	
function qf(){
		document.getElementById('pg9').style.display = 'block';		
		document.getElementById('pg8').style.display = 'none';	
}	
function qg(){
		document.getElementById('pg10').style.display = 'block';		
		document.getElementById('pg9').style.display = 'none';	
}	
function qh(){
		document.getElementById('pg11').style.display = 'block';		
		document.getElementById('pg10').style.display = 'none';	
}	
function qi(){
		document.getElementById('pg12').style.display = 'block';		
		document.getElementById('pg11').style.display = 'none';	
}	
var number = 0;
function qj(){
		document.getElementById('pg12').style.display = 'none';	

var q1 = document.juec.q1.value;
var q2 = document.juec.q2.value;
var q3 = document.juec.q3.value;
var q4 = document.juec.q4.value;
var q5 = document.juec.q5.value;
var q6 = document.juec.q6.value;
var q7 = document.juec.q7.value;
var q8 = document.juec.q8.value;
var q9 = document.juec.q9.value;
var q10 = document.juec.q10.value;
console.log(q1,q2,q3,q4,q5,q6,q7,q8,q9,q10)   
var num = parseFloat(q1) + parseFloat(q2) + parseFloat(q3)+ parseFloat(q4)+ parseFloat(q5)+ parseFloat(q6)+ parseFloat(q7)+ parseFloat(q8) +parseFloat(q9)+ parseFloat(q10);
number = num;

	    var mark=getCookie("mark");
    if (mark != "") {
		} else {
       var user = number;
       if (user != "" && user != null) {
           
           setCookie("mark", number, 30);
           
	    var usesr=getCookie("username");
          document.juec.username.value=usesr;          document.juec.mark.value=number;
          
 window.onbeforeunload = false;
    document.getElementById("juec").submit();
           
           
       }
	   
    }

	}
	function sharer() {
 mark = getCookie("mark");
		 if (mark != "") {
			 var num= mark;
    } else {
		
			 var num= number;
    }
	if(num >175) {var range = '8';}
else if(num >150) {var range = '7';}
else if(num >125) {var range = '6';}
else if(num >100) {var range = '5';}
else if(num >75) {var range = '4';}
else if(num >50) {var range = '3';}
else if(num >25) {var range = '2';}
else if(num >0) {var range = '1';}
else if(num =0) {var range = '0';}
		
	
     window.open("https://www.facebook.com/sharer/sharer.php?u=http://www.hostei.com/quiz/"+range+"8795341.html","",  "width=1000,height=500");  
		}

</script>

<div id="pg3" class="question">
<p  style="margin-top: 100px;    padding: 10px 30px;text-align:center;font-size:25px;letter-spacing:3px;
color:#FFF6A5;font-weight:bold;"><img width="280px" src="data/q1.png"/><br><br>求<i>x</i>。</p>
<div style="display: block;margin: auto;text-align: center;">
  <input type="radio" id="1" name="q1" value="0" onclick="qa()" style="display:none;"><label for="1">30°</label><br>
<input type="radio" id="2" name="q1" value="20" onclick="qa()" style="display:none;"><label for="2">45°</label><br>
<input type="radio" id="3" name="q1" value="20"  onclick="qa()" style="display:none;"><label for="3">60°</label><br>
<input type="radio" id="4" name="q1" value="20" onclick="qa()" style="display:none;"><label for="4">放弃作答</label><br>
</div>


</div>

<div id="pg4" class="question" style="animation:scroll 0.3s;">
<p  style="margin-top: 100px;    padding: 10px 30px;text-align:center;font-size:25px;letter-spacing:3px;
color:#FFF6A5;font-weight:bold;">11+11<sub>2</sub>+11<sub>8</sub></p><br>
<div style="display: block;margin: auto;text-align: center;">
<input type="radio" id="5" name="q2" value="0" onclick="qb()" style="display:none;"><label for="5">10111<sub>2</sub></label><br>
<input type="radio" id="6" name="q2" value="20" onclick="qb()" style="display:none;"><label for="6">10111</label><br>
<input type="radio" id="7" name="q2" value="20" onclick="qb()" style="display:none;"><label for="7">33</label><br>
<input type="radio" id="8" name="q2" value="20" onclick="qb()" style="display:none;"><label for="8">放弃作答</label><br>
</div>
</div>

<div id="pg5" class="question" style="animation:scroll 0.3s;">
<p  style="margin-top: 50px;    padding: 10px 30px;text-align:center;font-size:25px;letter-spacing:3px;
color:#FFF6A5;font-weight:bold;"><img src="data/q3.png" width="280px"/><br><br>y=2<i>x</i><sup>2</sup>+<i>x</i>b-9<br>M点为中心，求b。</p><br>
<div style="display: block;margin: auto;text-align: center;">
<input type="radio" id="9" name="q3" value="0" onclick="qc()" style="display:none;"><label for="9">0</label><br>
<input type="radio" id="10" name="q3" value="20" onclick="qc()" style="display:none;"><label for="10">1</label><br>
<input type="radio" id="11" name="q3" value="20" onclick="qc()" style="display:none;"><label for="11">2</label><br>
<input type="radio" id="12" name="q3" value="20" onclick="qc()" style="display:none;"><label for="12">放弃作答</label><br>
</div>
</div>
<div id="pg6" class="question" style="animation:scroll 0.3s;">
<div class="box1" style="height: 200px;margin-top: 20px; "><div class="plate"  style="   padding: 10px 30px;text-align:center;font-size:25px;letter-spacing:3px;font-weight:bold;">
<p style="padding: 1px 4px;overflow:hidden;">
A国：地势低平<br>B国：曾是英国殖民地<br>C国：伊斯兰国</p>

</div></div><br><p style="    padding: 10px 30px;text-align:center;font-size:25px;letter-spacing:3px;
color:#FFF6A5;font-weight:bold;">A国、B国、C国相邻，B国可能是？</p><br>
<div style="display: block;margin: auto;text-align: center;">
<input type="radio" id="13" name="q4" value="20" onclick="qd()" style="display:none;"><label for="13">孟加拉</label><br>
<input type="radio" id="14" name="q4" value="0" onclick="qd()" style="display:none;"><label for="14">印度</label><br>
<input type="radio" id="15" name="q4" value="20" onclick="qd()" style="display:none;"><label for="15">印尼</label><br>
<input type="radio" id="16" name="q4" value="20" onclick="qd()" style="display:none;"><label for="16">放弃作答</label><br>
</div>
</div>
<div id="pg7" class="question" style="animation:scroll 0.3s;">
<p  style="margin-top: 100px;    padding: 10px 30px;text-align:center;font-size:25px;letter-spacing:3px;
color:#FFF6A5;font-weight:bold;"><u>我们</u>哭了。</p><br>
<div style="display: block;margin: auto;text-align: center;">
<input type="radio" id="17" name="q5" value="20" onclick="qe()" style="display:none;"><label for="17">名词</label><br>
<input type="radio" id="18" name="q5" value="20" onclick="qe()" style="display:none;"><label for="18">动词</label><br>
<input type="radio" id="19" name="q5" value="20" onclick="qe()" style="display:none;"><label for="19">代词</label><br>
<input type="radio" id="20" name="q5" value="0" onclick="qe()" style="display:none;"><label for="20">放弃作答</label><br>
</div>
</div>
<div id="pg8" class="question" style="animation:scroll 0.3s;">
<p  style="margin-top: 100px;    padding: 10px 30px;text-align:center;font-size:25px;letter-spacing:3px;
color:#FFF6A5;font-weight:bold;">It's time to <u>rejuvenate</u> ourselves after a hectic study life!</p><br>
<div style="display: block;margin: auto;text-align: center;">
<input type="radio" id="21" name="q6" value="20" onclick="qf()" style="display:none;"><label for="21">change</label><br>
<input type="radio" id="22" name="q6" value="20" onclick="qf()" style="display:none;"><label for="22">transform</label><br>
<input type="radio" id="23" name="q6" value="0" onclick="qf()" style="display:none;"><label for="23">heal</label><br>
<input type="radio" id="24" name="q6" value="20" onclick="qf()" style="display:none;"><label for="24">放弃作答</label><br>
</div>
</div>
<div id="pg9" class="question" style="animation:scroll 0.3s;">
<p  style="margin-top: 100px;    padding: 10px 30px;text-align:center;font-size:25px;letter-spacing:3px;
color:#FFF6A5;font-weight:bold;">Ali telah dibuang sekolah kerana <u>meniru</u> tandatangan ibunya.</p><br>
<div style="display: block;margin: auto;text-align: center;">
<input type="radio" id="25" name="q7" value="20" onclick="qg()" style="display:none;"><label for="25">mencontoh</label><br>
<input type="radio" id="26" name="q7" value="0" onclick="qg()" style="display:none;"><label for="26">memalsukan</label><br>
<input type="radio" id="27" name="q7" value="20" onclick="qg()" style="display:none;"><label for="27">menjahatkan</label><br>
<input type="radio" id="28" name="q7" value="20" onclick="qg()" style="display:none;"><label for="28">放弃作答</label><br>
</div>
</div>
<div id="pg10" class="question" style="animation:scroll 0.3s;">
<div  style="margin-top: 100px;    padding: 10px 30px;text-align:center;font-size:25px;letter-spacing:3px;
color:#FFF6A5;font-weight:bold;"><p style="font-size:25px;">一名体重为40kg的选手以4m/s的速度完成200米赛跑。</p><p style="font-size:20px;">若以相同的功率背书包跑200米，需花多少时间？</p></div><br>
<div style="display: block;margin: auto;text-align: center;">
<input type="radio" id="29" name="q8" value="0" onclick="qh()" style="display:none;"><label for="29">50s</label><br>
<input type="radio" id="30" name="q8" value="20" onclick="qh()" style="display:none;"><label for="30">55s</label><br>
<input type="radio" id="31" name="q8" value="20" onclick="qh()" style="display:none;"><label for="31">60s</label><br>
<input type="radio" id="32" name="q8" value="20" onclick="qh()" style="display:none;"><label for="32">放弃作答</label><br>
</div>
</div>
<div id="pg11" class="question" style="animation:scroll 0.3s;">
<p  style="margin-top: 10px;    padding: 10px 30px;text-align:center;font-size:25px;letter-spacing:3px;
color:#FFF6A5;font-weight:bold;"><img width="200px" src="data/q9.png"/><br><br>实心铁球从质量为81g的空心铝制圆锥体匀速滑下，求铁球的功率。</p><br>
<div style="display: block;margin: auto;text-align: center;">
<input type="radio" id="33" name="q9" value="20" onclick="qi()" style="display:none;"><label for="33">0W</label><br>
<input type="radio" id="34" name="q9" value="0" onclick="qi()" style="display:none;"><label for="34">89/77W</label><br>
<input type="radio" id="35" name="q9" value="20" onclick="qi()" style="display:none;"><label for="35">10W</label><br>
<input type="radio" id="36" name="q9" value="20" onclick="qi()" style="display:none;"><label for="36">放弃作答</label><br>
</div>
</div>
<div id="pg12" class="question" style="animation:scroll 0.3s;">
<p  style="margin-top: 100px;    padding: 10px 30px;text-align:center;font-size:25px;letter-spacing:3px;
color:#FFF6A5;font-weight:bold;"><u>怒发冲冠</u>出自？</p><br>
<div style="display: block;margin: auto;text-align: center;">
<input type="radio" id="37" name="q10" value="20" onclick="qj()" style="display:none;"><label for="37">《满红红》</label><br>
<input type="radio" id="38" name="q10" value="0" onclick="qj()" style="display:none;"><label for="38">《满江红》</label><br>
<input type="radio" id="39" name="q10" value="20" onclick="qj()" style="display:none;"><label for="39">《论语》</label><br>
<input type="radio" id="40" name="q10" value="20" onclick="qj()" style="display:none;"><label for="40">放弃作答</label><br>
<input type="hidden" id="username" name="username">
<input type="hidden" id="mark" name="mark">
</div>
</div>




</div>
</form>
<div id="pg13" class="question" style="animation:scroll2 3s;
    margin-top: 130px;">
<div id="mark" style="margin-top: 130px;margin:auto;text-align:center;"><span id="img" style="text-align: center;
    margin: auto;
    font-size: 80px;
    font-weight: bold;
    color: white;"></span><br>
    <p id="topic" style="margin-top: 10px;text-align:center;font-size:25px;letter-spacing:3px;
color:white;font-weight:bold;
    margin-bottom: 10px;">自以为是的学霸！</p><div id="cross" style="width: 250px;
    height: 10px;
    margin: auto;"><span id="details" style="font-size: 15px;
    color: white;
    margin-top: 10px;">你知道吗，答对一题会扣20分噢！有没有看清楚<u onclick="nextt()">服务条款</u>呢？</span></div><br><br>

    
    </div>

<div class="button" id="button4"><button onclick="sharer()" style="    width: 200px;border-radius:100px;
    margin-top: 20px;font-size:15px;
    margin-top: 10px;">分享到Facebook</button><br><a href="deadpaper" style="font-size:10px;color:white;">下载死亡考卷</a> </div><br>
 

</div>

<span id="what"></span>
</body>
</html>