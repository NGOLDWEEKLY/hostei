
<!DOCTYPE HTML>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>动漫图画上传处</title>
<meta property="og:description" content="让学霸一起陪我们读书。">
<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
<meta name="viewport" content="width=device-width" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js">
</script>

<script>

$(document).keydown(function(event) {
if (event.ctrlKey==true && (event.which == '61' || event.which == '107' || event.which == '173' || event.which == '85' ||  event.which == '86' ||  event.which == '67' ||  event.which == '123' ||  event.which == '117' || event.which == '109'  || event.which == '187'  || event.which == '189'  ) ) {
        event.preventDefault();
     }
    // 107 Num Key  +
    // 109 Num Key  -
    // 173 Min Key  hyphen/underscor Hey
    // 61 Plus key  +/= key
});

$(window).bind('mousewheel DOMMouseScroll', function (event) {
       if (event.ctrlKey == true) {
       event.preventDefault();
       }
});
    $(document).keydown(function(event){
    if(event.keyCode==123){
        return false;
    }
    else if (event.ctrlKey && event.shiftKey && event.keyCode==73){        
             return false;
    }
});

$(document).on("contextmenu",function(e){        
   e.preventDefault();
});

    
</script>
        <style>
        input:focus,
select:focus,
textarea:focus,
button:focus {
    outline: none;
}
        #put{
            margin-top:0px;
        }
        #room::-webkit-scrollbar-track
{
	border-radius: 10px;    background-color: rgba(0, 0, 0, 0.41);
}
#room {
background: #b07b00;
    
}
#room::-webkit-scrollbar
{
	width: 12px;
}

#room::-webkit-scrollbar-thumb
{
	border-radius: 10px;    background-color: rgba(0, 0, 0, 0.41);
}

        body{
        margin:auto;
        background:#ffb200;
        font-family:Microsoft Yahei;
        position: absolute;
top: 50%;
left: 50%;
transform: translateX(-50%) translateY(-50%);
        
    }
        #chat {
            background:#e2e2e2;
            border-style:none;
    padding-left: 10px;
    height: 60px;
    width: 260px;
        }

#btnsubmit {
    background: #ffffff;
    margin-left: 2px;
    border-style: none;
    width: 30px;
    font-size: 12px;
    height: 32px;
    color:#ffb200;
    cursor:pointer;
    transition: ease 0.4s;
            }
            #btnsubmit:hover{
        background:#ffb200;
                color:white;
    border-style: solid;
    border-width:1px;
                border-color:white;
            }
            
        </style>
<script>



function setCookie(cname,cvalue,exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
    window.onload = function(){
                        $('#room').stop().animate({
  scrollTop: $('#room')[0].scrollHeight
}, 800);
                var user=getCookie("chatuser");
                
        var i;
        var las = "you " +user;
var name =  document.getElementsByClassName(las);
for (i = 0; i < name.length; i++) { 
  document.getElementsByClassName(las)[i].style.background = "#fffa78";
  document.getElementsByClassName(las)[i].style.marginLeft = "80px";
}

	    if (user == "") {
document.getElementById('pg2').style.display="none";
document.getElementById('pg1').style.display="block";
        
		} else if(user !== ""){
		    
            document.getElementById('user').value = user;
            document.getElementById('user2').value = user;
                    autoScrolling();
                
var name2 =  document.getElementsByClassName(user);
var name3 =  document.getElementsByTagName("p");
var latest =[name2.length - 1];
var latest3 =[name3.length - 1];
var late = name2 + latest ;
var late3 = name3 + latest3 ;
var lates = late.innerHTML;
var mes =   getCookie("new_message");   
var userract = late3.innerHTML;
if(mes !== "" && mes !== userract && userract !== user){
    setCookie("new_message", userract, 30); 
 
}else{

    setCookie("new_message", userract, 30);  }                    
		    
		}
	     
        var stra = document.getElementsByTagName("h3");
        var i;
for (i = 0; i < stra.length; i++) {
    var b = stra[i].innerHTML;
 var a = b.includes('png');
 var d = b.includes('jpg');
 var e = b.includes('jpeg');
 var g = b.includes('gif');
        if(a == true || d == true|| e == true|| g == true){
           var c= b.replace(/\s/g, '')
        stra[i].innerHTML = "<img src='uploads/"+ c + "' width='100px;'>";
        autoScrolling();
    }   
}
    }
    
    function myfunction(x){
        
var n = x.includes("fuck");
        if(n == true){
            document.getElementById('chat').value = 'I swear, but I wont say nonsense anymore.';
            document.getElementById('form').submit();
        }
       var o = x.includes("shit");
        if(o == true){
            document.getElementById('chat').value = 'I swear, but I wont say nonsense anymore.';
                        document.getElementById('form').submit();
        }
         var ao = x.includes("wtf");
        if(ao == true){
            document.getElementById('chat').value = 'I swear, but I wont say nonsense anymore.';
                        document.getElementById('form').submit();
        }
         var abo = x.includes("WTF");
        if(ao == true){
            document.getElementById('chat').value = 'I swear, but I wont say nonsense anymore.';
                        document.getElementById('form').submit();
        }
       var m = x.includes("他妈");
        if(m == true){
            document.getElementById('chat').value = '我发誓不再爆粗了。';
                        document.getElementById('form').submit();
        }
       var am = x.includes("鸡白");
        if(am == true){
            document.getElementById('chat').value = '我发誓不再爆粗了。';
                        document.getElementById('form').submit();
        }
        var vam = x.includes("打飞机");
        if(vam == true){
            document.getElementById('chat').value = '请不要玩成人游戏。';
                        document.getElementById('form').submit();
        }        var vvam = x.includes("A片");
        if(vvam == true){
            document.getElementById('chat').value = '请不要玩成人游戏。';
                        document.getElementById('form').submit();
        }
       var abm = x.includes("walao");
        if(abm == true){
            document.getElementById('chat').value = '我发誓不再爆粗了。';
                        document.getElementById('form').submit();
        }
       var acm = x.includes("哇老");
        if(acm == true){
            document.getElementById('chat').value = '我发誓不再爆粗了。';
                        document.getElementById('form').submit();
        }
       var acmn = x.includes("哇佬");
        if(acmn == true){
            document.getElementById('chat').value = '我发誓不再爆粗了。';
                        document.getElementById('form').submit();
        }
        
    }
    //function refresh()
    //{
        //var user = getCookie("chatuser");
         
	    //if (user !== "") {
        //var y= document.getElementById('room').scrollHeight;
      //  var z= document.getElementById('room').scrollTop;
       
             
    //    var data = document.getElementById('chat').value;
  //      var pic = document.getElementById('picture').value;
// if ((data == "" || data == null || data == undefined) && 500+z >= y && pic ==""){
        //     location.reload();        
      //  }
        
        
    //}
        
  //  }
    
// setInterval(refresh , 4000); 
        
function set(){
var x =document.getElementById('name').value;
           setCookie("chatuser", x, 30);  
             
document.getElementById('pg1').innerHTML="";
document.getElementById('pg2').style.display="block";
    document.getElementById('user').value = x;
                 location.reload();        
}
</script>
<script>

function autoScrolling() {
        var divFirst = document.getElementById("room");
    divFirst.scrollTop = divFirst.scrollHeight;
document.getElementById("chat").focus(); 
}
        </script>
        <style>
    
        body {
      font-family:Arial,'Times New Roman','Microsoft YaHei',SimHei; 

        }
        p{
           font-size:10px; 
            color:#b88900;
        }
        h3{
            color:#530101;
           margin-top:-5px; 
           -ms-word-break: break-all;
    word-break: break-all;

    font-size: 20px;
     word-break: break-word;

    -webkit-hyphens: auto;
       -moz-hyphens: auto;
        -ms-hyphens: auto;
            hyphens: auto;

    padding-right: 15px;
        }
        .you{  
            background:#f1f1f1;
            padding-left:15px;
            border-radius:15px;
            padding-top:0.4px;
            padding-bottom:0.2px;
            margin-bottom:10px;
              width: 120px;
   -moz-border-radius:    10px;
   -webkit-border-radius: 10px;
   border-radius:         10px;
   animation:show 0.5s;
        }
      @keyframes show {
          0%{opacity:0;}
          99%{opacity:0;}
          100%{opacity:1;}
          
      }
        </style>
        </head>

<body>
    

    
    <div style="    width: 305px;
    background: #795104;
    margin: auto;
    height: 100px;"><p style="    padding-top: 20px;letter-spacing:6px;font-size:40px;text-align:center;font-weight:bold;color:white;" onclick="refresh()">E I 聊天室</p></div>
 <div id="room"  style=" margin: auto;
    clear: both;
    padding: 1px 20px;
    overflow-y: scroll;
    max-height: 300px;
    width: 230px;
    overflow-x: hidden;
    height: 300px;">
         <div class='you' style='margin-top:10px; background:#e1e1e1;color:white;
   animation:show 0.1s;'><p style="color:#530101">Admin</p><h3 >大家开始聊天吧！</h3></div>

<script>
function shower() {
    
 if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
var ids= document.getElementsByClassName('you').length;
        xmlhttp.open("POST","http://www.hostei.com/v/chatroom/message.php?id="+ids,true);
        xmlhttp.send();
                xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
               

                document.getElementById("room").insertAdjacentHTML('beforeend',this.responseText);

            }
        };
}



function uploader() {
    var str = document.getElementById('user').value;
    var str2 = document.getElementById('chat').value;
    if(str != "" && str2 != ""){
        xmlhttp.open("POST","http://www.hostei.com/v/chatroom/send/",true);
        
 xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xmlhttp.send("user="+str+"&chat=" + str2);
        document.getElementById('chat').value = "";

        }
}

var download= setInterval(shower,1000);
$(document).ready(function(){
$("#chat").on('keyup', function (e) {
    if (e.keyCode == 13) {
        e.preventDefault();
        uploader();
                                $('#room').stop().animate({
  scrollTop: $('#room')[0].scrollHeight
}, 800);
    }
});
});
</script>
<span id="scroll"></span></div>

<div id="div">
</div>
<div >
<div id="pg1" style="text-align:center;font-family:Microsoft YaHei;color:white;display:none;">
<input placeholder="输入名字以加入聊天" type="name" style="margin-top:10px;width:270px;border-style:none;background:#e1e1e1;height:30px;text-align:center" maxlength="20" id="name" autofocus/><br><button onclick="set()" style="background:white;border-style:solid;font-family:Microsoft YaHei;font-weight:bold;width:273px;height:30px;color:#ffb200;letter-spacing:3px;border-color:white;" required>继续</button></div>
<div id="pg2" style="">

    <span id="test12" name="test12"></span>

<script>


</script>
<div id="form" style="
    margin: auto;    width: 270px;" return="false">
    <span id="input" style="
    margin: auto;
    width: 250px;
">
        <input type='hidden' name='user' id='user' /><input type='text' name='chat' id='chat' onfocus='autoScrolling()' onkeyup='myfunction(this.value)' placeholder='输入消息...' autofocus autocomplete='off'/></span>
</div>
<script>
function myfunc(){
    document.getElementById("chat").value ="pictures";
}
function pic(){
var pic= document.getElementById("fileToUpload").value;
    if(pic != ""){
        var str = document.getElementById("fileToUpload").value;
        var res= str.split('\\').pop();
        document.getElementById("picture").value = res;
        document.getElementById("pictures").submit();
        
    }
  
    
}
    setInterval(function(){ pic() }, 3000);
</script>
<form id="pictures" action="upload.php" method="post" enctype="multipart/form-data" style="position:absolute;margin-top:-50px;margin-left:240px;">        <input type='hidden' name='user2' id='user2' />  <input type='hidden' name='picture' id='picture' />
    <label for="fileToUpload" style="font-size:25px;cursor:pointer;">	&#128247;</label><input style="display:none;" type="file" accept="image/*" name="fileToUpload" id="fileToUpload" onclick="myfunc()">
</form>

</div></div>

</body>
</html>