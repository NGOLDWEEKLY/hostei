<?php
// Get connection
$servername = "localhost";
$username = "id2188560_hostei";
$password = "Uo02ovov36tb,[";
$dbname = "id2188560_hostei";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    echo "Connection failed. Please try again later.";
    echo "<br>";
}
$md = $_REQUEST["md"];
$token = $_REQUEST["token"];
$admt = "SELECT * from ei_host_inf where ei_md ='$md'";
 if ($result=mysqli_query($conn,$admt))
  {
   if(mysqli_num_rows($result) > 0)
    {
      echo "Exists";
      exit;
    }
  else{


    $temp_search = "SELECT * from temp_lg where ei_md ='$md', t_token ='$token'";
     if ($result=mysqli_query($conn,$temp_search))
  {
   if(mysqli_num_rows($result) > 0)
    {
 
$ei = "INSERT INTO ei_host_inf (ei_md, username) VALUES ('$md','$u')";

if(mysqli_query($conn, $ei)) {
   echo  "can";
}else{
    echo  "cannot";
 

}
$host = "INSERT INTO host_dt (ei_md, username, pw, token, exp_d) VALUES ('$md','$u','$pw','$token','$exp')";
if(mysqli_query($conn, $host)) {
   echo  "can";
}else{
    echo  "cannot";
 

}
$chat = "INSERT INTO chat_dt (ei_md) VALUES ('$md')";
if(mysqli_query($conn, $chat)) {
   echo  "can";
}else{
    echo  "cannot";
 

}
$quiz = "INSERT INTO quiz_dt (ei_md) VALUES ('$md')";
if(mysqli_query($conn, $quiz)) {
   echo  "can";
}else{
    echo  "cannot";
 

}
$game = "INSERT INTO game_dt (ei_md) VALUES ('$md')";
if(mysqli_query($conn, $game)) {
   echo  "can";
}else{
    echo  "cannot";
 

}
$feed = "INSERT INTO feed_dt (ei_md) VALUES ('$md')";
if(mysqli_query($conn, $feed)) {
   echo  "can";
}else{
    echo  "cannot";
 

}
    }
    
  }
  }}
else
{
    echo "Query Failed.";
}







mysqli_close($conn); 


?>