

<?php





$to = "najffdak1k@gmail.com";
$subject = "My subject";
$txt = "Hello world!";
$headers = "From: webmaster@example.com" . "\r\n" .
"CC: somebodyelse@example.com";

mail($to,$subject,$txt,$headers);

$to      = 'ngoldweekly@gmail.com';
$subject = 'Ngold, last step to claim your EI account.';
$message = '<html>Please click the button below to verify your account<button>VERIFY</button><p>Please be notified that reply to "support@hostei.ga" instead of "noreply@hostei.com" to prevent bugs and anonymous errors.</p></html>';
$headers = 'From: "Host EI" <noreply@hostei.com>' . "\r\n" .
    'Reply-To: "Host EI" <support@hostei.ga>' . "\r\n" .
    'MIME-Version: 1.0' ."\r\n" .
        'Content-Type: text/html; charset=ISO-8859-1' ."\r\n"     ;

mail($to, $subject, $message, $headers);


if(@mail($to, $subject, $message, $headers))
{
  echo "Mail Sent Successfully";
}else{
  echo "Mail Not Sent";
}




$servername = "localhost";
$username = "id2188560_hostei";
$password = "Uo02ovov36tb,[";
$dbname = "id2188560_hostei";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    echo "Connection failed. Please try again later.";
    echo "<br>";
}
$md = $_REQUEST["md"];
$pw = $_REQUEST["p"];
echo $md;
$str = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ01234567891011121314151617181920212223242526';


$shuffled = str_shuffle($str);
    
$t_token = substr($shuffled,1,30);

$time= date("Y/m/d H:i:s");
$t_exp=date('Y/m/d H:i:s',strtotime($time.'+ 15 minute'));


$admt = "SELECT * from ei_host_inf where ei_md ='$md'";
 if ($result=mysqli_query($conn,$admt))
  {
   if(mysqli_num_rows($result) > 0)
    {
      echo "Exists";
      exit;
    }
  else
      echo "Great! Next step.";
    
    

$temp = "INSERT INTO temp_lg (ei_md, pw, temp_token, temp_exp_d) VALUES ('$md','$pw','$t_token','$t_exp')";
if(mysqli_query($conn, $temp)) {
   echo  "can";
  
}else{
    echo  "cannot";
 

}
  }
else
    echo "Query Failed.";
          exit;










$str = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';


$t_token = str_shuffle($str);

$t_token = substr($t_token,1,30);

echo $t_token . "<br>";

echo "Today is " . date("Y/m/d") . "<br>";

echo "The time is " . date("h:i:sa"). "<br>";

$time= date("Y/m/d H:i:s");
$new_time=date('Y/m/d H:i:s',strtotime($time.'+ 15 minute'));
echo $new_time;







require_once 'https://wxcz.000webhostapp.com/EILogin/swift/lib/swift_required.php';

$transport = Swift_SmtpTransport::newInstance('smtp.gmail.com', 465, "ssl")
  ->setUsername('hosteiappservices@gmail.com')
  ->setPassword('Uo02ovov36tb,[');

$mailer = Swift_Mailer::newInstance($transport);

$message = Swift_Message::newInstance('Test Subject')
  ->setFrom(array('abc@example.com' => 'ABC'))
  ->setTo(array('ngoldweekly@gmail.com'))
  ->setBody('This is a test mail.');

$result = $mailer->send($message);


mysqli_close($conn); 

?>