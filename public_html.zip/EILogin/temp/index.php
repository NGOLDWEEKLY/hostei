<?php
// Get connection
$servername = "localhost";
$username = "id2188560_hostei";
$password = "Uo02ovov36tb,[";
$dbname = "id2188560_hostei";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    echo "Connection failed. Please try again later.";
    echo "<br>";
}
$md = $_REQUEST["md"];
$pw = $_REQUEST["p"];

if(empty($md) || empty($pw)){      echo "stop";
      exit;}
$str = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ01234567891011121314151617181920212223242526';


$shuffled = str_shuffle($str);
    
$t_token = substr($shuffled,1,30);

$time= date("Y-m-d H:i:s");
$t_exp=date('Y-m-d H:i:s',strtotime($time.'+ 30 minute'));


$admt = "SELECT * from ei_host_inf where ei_md ='$md'";
 if ($result=mysqli_query($conn,$admt))
  {
   if(mysqli_num_rows($result) > 0)
    {
      echo "2.0d";
      exit;
    }
  else
  
  $temp_e = "SELECT * from temp_lg where ei_md ='$md'";
 if ($result=mysqli_query($conn,$temp_e))
 {
      if(mysqli_num_rows($result) > 0)
    {
        if(("SELECT temp_exp_d from temp_lg where ei_md ='$md'") < $t_exp){
        exit;
            
        }
        else{
        $temp_e_a = "UPDATE temp_lg SET temp_token='$t_token', temp_exp_d ='$t_exp' WHERE ei_md = '$md'";

      echo "2.0bx";
       
$to      = $md;
$subject = 'Last step to claim your EI account.';
$message = '<html>
<head>
<style>
@media  (max-width: 899px){
body{
    background: #f8f8f8;
    font-family: Arial,"Quicksand",微軟正黑體, "Microsoft Jhenghei", sans-serif;
    top: 0;
    border: 0;
    margin: 0;    overflow-x: hidden;
}



#logo, #bar,#lang{
    display: inline-block;
}
#logo-detail{
    font-family: Arial,"Quicksand",微軟正黑體, "Microsoft Jhenghei", sans-serif;
    top: 0;
        color: #8d8d8d;
    margin: 0;
    margin-top: -20px;

    text-align: center;

    font-size: 0.7em;    letter-spacing: 2px;
}
.logo{
    width: 100%;
    text-align: center;
    
    
    height: 200px;
}
.logo-title{
    
    display: inline-block;
     cursor:pointer;
    margin-top: 25px;
    transition:ease 0.6s;
}
.svg-holder{
    background-image: url(http://www.hostei.com/img/old-man-head.svg);
    background-position: center center;
    background-repeat: no-repeat;
    width: 200px;
    height: 200px;
    border-radius: 50%;
    
    position: absolute;
    z-index: 999;
    background-size: auto 180px;
    margin-left: 8px;
    
    transition: ease 0.6s;
    margin-top: -20px;

}
.holder{
	    box-shadow: 2px 2px 11px #d0d0d0;
}
.header-background{
        position: absolute;
    z-index: -9999;
    background: white;
    height: 0;
    top: 0px;
    left: 0;
    right: 0;
    
    border-right: none;
    
}

#php-echo{

text-align:center;
    
    
}

#echo-console {
    width: 60%;
    text-align: center;
    margin: auto;
    color: #787878;
    line-height: 25px;
	
    font-size: 14px;
}
#echo-verf button {
    width: 60%;
    max-width: 500px;
    height: 65px;
    font-size: 26px;
    background: white;
    color: #787878;
    cursor: pointer;
    border-radius: 50px;
    border: none;
    outline: none;
    margin-top: 20px;
    box-shadow: 1px 2px 3px #d0d0d0;
	font-weight:bold;
}		#echo-verf button:hover{
			background:#fff;
			}
#echo-verf button:active{
        background: linear-gradient(#e1e1e1,#f1f1f1);
    
}

h1{
    
    
    font-size: 35px;
	margin:0;
    
}    
.echo-cancel a{
    margin-top: 20px;
    line-height: 50px;
    font-size: 15px;
    text-decoration: none;
    color: #a1a1a1;
}

 
}
@media screen and (min-width: 900px) {
body{
	
    background: #f8f8f8;
    font-family: Arial,"Quicksand",微軟正黑體, "Microsoft Jhenghei", sans-serif;
    top: 0;
    border: 0;
    margin: 0;    overflow-x: hidden;
}

#logo, #bar,#lang{
    display: inline-block;
}

#logo-detail{
    font-family: Arial,"Quicksand",微軟正黑體, "Microsoft Jhenghei", sans-serif;
    top: 0;
        color: #8d8d8d;
    margin: 0;
    margin-top: -20px;

    text-align: center;

    font-size: 0.7em;    letter-spacing: 2px;
}
.logo{
    width: 100%;
    text-align: center;
    
    
    height: 200px;
}
.logo-title{
    
    display: inline-block;
    margin-top: 25px;
    cursor:pointer;
    transition:ease 0.6s;
}
.header-background{
        position: absolute;
    z-index: -9999;
    background: white;
    height: 0;
    top: 0px;
    left: 0;
    right: 0;
    
    
}
.holder{
	    box-shadow: 2px 2px 11px #d0d0d0;
}
#php-echo{

text-align:center;
    
    line-height: 30px;
    
}
h1{
	
    line-height: 30px;}
#echo-console {
    width: 60%;
    text-align: center;
    margin: auto;
    color: #787878;
    line-height: 25px;
    font-size: 14px;
}
#echo-verf button {
    width: 60%;
    max-width: 500px;
    height: 65px;
    font-size: 26px;
    background: white;
    color: #787878;
    cursor: pointer;
    border-radius: 50px;
    border: none;
    outline: none;
    margin-top: 20px;
    box-shadow: 1px 2px 3px #d0d0d0;
		font-weight:bold;
}		#echo-verf button:hover{
			background:#fff;
			}
		
#echo-verf button:active{
        background: linear-gradient(#e1e1e1,#f1f1f1);
    
}


h1{
    margin:0;
    font-size: 35px;
}

.echo-cancel a{
    margin-top: 20px;
    line-height: 50px;
    font-size: 15px;
    text-decoration: none;
    color: #a1a1a1;
}



}

</style>
 <link rel="shortcut icon" href="http://www.hostei.com/img/favicon.png?v=3">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
<meta name="viewport" content="width=device-width">
<meta name="google-site-verification" content="XwHDAaem5TzpQQif796pOcH4hZcEqC2Yqz5f2IGHRmQ">
<title>host EI -Email Verification</title>

</head>
<body  style="top:0;bottom:0;left:0;right:0;background: #f8f8f8;
    font-family: Arial,"Quicksand",微軟正黑體, "Microsoft Jhenghei", sans-serif;
  
    border: 0;
    margin: 0;    overflow-x: hidden;">

<div class="holder" style="background:#f8f8f8;">
    <div class="header-background"></div>
<div class="header" id="header">
<div class="logo" id="logo" style="height: 300px;    width: 100%;
    text-align: center;"><a style="text-decoration:none;color:grey" href="http://www.hostei.com" target="_blank">
<div class="logo-title">
<img src="https://wxcz.000webhostapp.com/img/logo.png" width="221px">
<p id="logo-detail" style=" font-family: Arial,"Quicksand",微軟正黑體, "Microsoft Jhenghei", sans-serif;
    top: 0;
        color: #8d8d8d;
    margin: 0;
    margin-top: -20px;

    text-align: center;

    font-size: 0.7em;    letter-spacing: 2px;text-decoration: none;
    color: grey;
    letter-spacing: 1.2px;
    font-size: 12px;">EXPERIENCING &amp; INTELLIGENCE</p></div></a></div>


</div></div>
<div id="php-echo" style="background:#f8f8f8;
text-align:center;
    ">
<div id="echo-console" class="echo-console" style="    width: 60%;
    text-align: center;
    margin: auto;
    color: #787878;
    line-height: 25px;
	
    font-size: 14px;"><h1 style="margin:0;    line-height: 30px;">Email Verification</h1><p>Hey there, you have requested for an EI Account. Please click the button below to verify your identity. <br>(Not you? Just ignore this mail and delete it.)</p></div>
<div id="echo-verf">
<a style="cursor:pointer" href="http://www.hostei.com/EILogin/temp/ver?md=' .$md. '&token=' .$t_token. '"><button style="    width: 55%;
    max-width: 500px;
    height: 65px;
    font-size: 26px;
    color: #f8f8f8;
    border-radius: 50px;
    border: none;
    outline: none;
    margin-top: 20px;
    font-weight: bold;
    background: #787878;
    cursor: pointer;
">Verify Account</button></a>

</div>
<div id="echo-cancel" class="echo-cancel">
    <a style="    margin-top: 20px;
    line-height: 50px;
    font-size: 15px;
    text-decoration: none;
    color: #a1a1a1;" href="http://www.hostei.com/">Back to home</a>
    </div>
    </div></body></html>';
$headers = 'From: "Host EI" <noreply@hostei.com>' . "\r\n" .
    'Reply-To: "Host EI" <support@hostei.ga>' . "\r\n" .
    'MIME-Version: 1.0' ."\r\n" .
        'Content-Type: text/html; charset=ISO-8859-1' ."\r\n"     ;

mail($to, $subject, $message, $headers);


if(@mail($to, $subject, $message, $headers))
{
  echo "1y";
}else{
  echo "0y";
}

      
      exit;}
    }
 }
 else{
$temp = "INSERT INTO temp_lg (ei_md, pw, temp_token, temp_exp_d) VALUES ('$md','$pw','$t_token','$t_exp')";
if(mysqli_query($conn, $temp)) {
   echo  "2.0bx";
  
$to      = $md;
$subject = 'Last step to claim your EI account.';
$message = '<html>
<head>
<style>
@media  (max-width: 899px){
body{
    background: #f8f8f8;
    font-family: Arial,"Quicksand",微軟正黑體, "Microsoft Jhenghei", sans-serif;
    top: 0;
    border: 0;
    margin: 0;    overflow-x: hidden;
}



#logo, #bar,#lang{
    display: inline-block;
}
#logo-detail{
    font-family: Arial,"Quicksand",微軟正黑體, "Microsoft Jhenghei", sans-serif;
    top: 0;
        color: #8d8d8d;
    margin: 0;
    margin-top: -20px;

    text-align: center;

    font-size: 0.7em;    letter-spacing: 2px;
}
.logo{
    width: 100%;
    text-align: center;
    
    
    height: 200px;
}
.logo-title{
    
    display: inline-block;
     cursor:pointer;
    margin-top: 25px;
    transition:ease 0.6s;
}
.svg-holder{
    background-image: url(http://www.hostei.com/img/old-man-head.svg);
    background-position: center center;
    background-repeat: no-repeat;
    width: 200px;
    height: 200px;
    border-radius: 50%;
    
    position: absolute;
    z-index: 999;
    background-size: auto 180px;
    margin-left: 8px;
    
    transition: ease 0.6s;
    margin-top: -20px;

}
.holder{
	    box-shadow: 2px 2px 11px #d0d0d0;
}
.header-background{
        position: absolute;
    z-index: -9999;
    background: white;
    height: 0;
    top: 0px;
    left: 0;
    right: 0;
    
    border-right: none;
    
}

#php-echo{

text-align:center;
    
    
}

#echo-console {
    width: 60%;
    text-align: center;
    margin: auto;
    color: #787878;
    line-height: 25px;
	
    font-size: 14px;
}
#echo-verf button {
    width: 60%;
    max-width: 500px;
    height: 65px;
    font-size: 26px;
    background: white;
    color: #787878;
    cursor: pointer;
    border-radius: 50px;
    border: none;
    outline: none;
    margin-top: 20px;
    box-shadow: 1px 2px 3px #d0d0d0;
	font-weight:bold;
}		#echo-verf button:hover{
			background:#fff;
			}
#echo-verf button:active{
        background: linear-gradient(#e1e1e1,#f1f1f1);
    
}

h1{
    
    
    font-size: 35px;
	margin:0;
    
}    
.echo-cancel a{
    margin-top: 20px;
    line-height: 50px;
    font-size: 15px;
    text-decoration: none;
    color: #a1a1a1;
}

 
}
@media screen and (min-width: 900px) {
body{
	
    background: #f8f8f8;
    font-family: Arial,"Quicksand",微軟正黑體, "Microsoft Jhenghei", sans-serif;
    top: 0;
    border: 0;
    margin: 0;    overflow-x: hidden;
}

#logo, #bar,#lang{
    display: inline-block;
}

#logo-detail{
    font-family: Arial,"Quicksand",微軟正黑體, "Microsoft Jhenghei", sans-serif;
    top: 0;
        color: #8d8d8d;
    margin: 0;
    margin-top: -20px;

    text-align: center;

    font-size: 0.7em;    letter-spacing: 2px;
}
.logo{
    width: 100%;
    text-align: center;
    
    
    height: 200px;
}
.logo-title{
    
    display: inline-block;
    margin-top: 25px;
    cursor:pointer;
    transition:ease 0.6s;
}
.header-background{
        position: absolute;
    z-index: -9999;
    background: white;
    height: 0;
    top: 0px;
    left: 0;
    right: 0;
    
    
}
.holder{
	    box-shadow: 2px 2px 11px #d0d0d0;
}
#php-echo{

text-align:center;
    
    line-height: 30px;
    
}
h1{
	
    line-height: 30px;}
#echo-console {
    width: 60%;
    text-align: center;
    margin: auto;
    color: #787878;
    line-height: 25px;
    font-size: 14px;
}
#echo-verf button {
    width: 60%;
    max-width: 500px;
    height: 65px;
    font-size: 26px;
    background: white;
    color: #787878;
    cursor: pointer;
    border-radius: 50px;
    border: none;
    outline: none;
    margin-top: 20px;
    box-shadow: 1px 2px 3px #d0d0d0;
		font-weight:bold;
}		#echo-verf button:hover{
			background:#fff;
			}
		
#echo-verf button:active{
        background: linear-gradient(#e1e1e1,#f1f1f1);
    
}


h1{
    margin:0;
    font-size: 35px;
}

.echo-cancel a{
    margin-top: 20px;
    line-height: 50px;
    font-size: 15px;
    text-decoration: none;
    color: #a1a1a1;
}



}

</style>
 <link rel="shortcut icon" href="http://www.hostei.com/img/favicon.png?v=3">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
<meta name="viewport" content="width=device-width">
<meta name="google-site-verification" content="XwHDAaem5TzpQQif796pOcH4hZcEqC2Yqz5f2IGHRmQ">
<title>host EI -Email Verification</title>

</head>
<body  style="top:0;bottom:0;left:0;right:0;background: #f8f8f8;
    font-family: Arial,"Quicksand",微軟正黑體, "Microsoft Jhenghei", sans-serif;
  
    border: 0;
    margin: 0;    overflow-x: hidden;">

<div class="holder" style="background:#f8f8f8;">
    <div class="header-background"></div>
<div class="header" id="header">
<div class="logo" id="logo" style="height: 300px;    width: 100%;
    text-align: center;"><a style="text-decoration:none;color:grey" href="http://www.hostei.com" target="_blank">
<div class="logo-title">
<img src="https://wxcz.000webhostapp.com/img/logo.png" width="221px">
<p id="logo-detail" style=" font-family: Arial,"Quicksand",微軟正黑體, "Microsoft Jhenghei", sans-serif;
    top: 0;
        color: #8d8d8d;
    margin: 0;
    margin-top: -20px;

    text-align: center;

    font-size: 0.7em;    letter-spacing: 2px;text-decoration: none;
    color: grey;
    letter-spacing: 1.2px;
    font-size: 12px;">EXPERIENCING &amp; INTELLIGENCE</p></div></a></div>


</div></div>
<div id="php-echo" style="background:#f8f8f8;
text-align:center;
    ">
<div id="echo-console" class="echo-console" style="    width: 60%;
    text-align: center;
    margin: auto;
    color: #787878;
    line-height: 25px;
	
    font-size: 14px;"><h1 style="margin:0;    line-height: 30px;">Email Verification</h1><p>Hey there, you have requested for an EI Account. Please click the button below to verify your identity. <br>(Not you? Just ignore this mail and delete it.)</p></div>
<div id="echo-verf">
<a style="cursor:pointer" href="http://www.hostei.com/EILogin/temp/ver?md=' .$md. '&token=' .$t_token. '"><button style="    width: 55%;
    max-width: 500px;
    height: 65px;
    font-size: 26px;
    color: #f8f8f8;
    border-radius: 50px;
    border: none;
    outline: none;
    margin-top: 20px;
    font-weight: bold;
    background: #787878;
    cursor: pointer;
">Verify Account</button></a>

</div>
<div id="echo-cancel" class="echo-cancel">
    <a style="    margin-top: 20px;
    line-height: 50px;
    font-size: 15px;
    text-decoration: none;
    color: #a1a1a1;" href="http://www.hostei.com/">Back to home</a>
    </div>
    </div></body></html>';
$headers = 'From: "Host EI" <noreply@hostei.com>' . "\r\n" .
    'Reply-To: "Host EI" <support@hostei.ga>' . "\r\n" .
    'MIME-Version: 1.0' ."\r\n" .
        'Content-Type: text/html; charset=ISO-8859-1' ."\r\n"     ;

mail($to, $subject, $message, $headers);


if(@mail($to, $subject, $message, $headers))
{
  echo "1y";
}else{
  echo "0y";
}



}else{
    echo  "2.0cy";
 

}



}
  }
else
    echo "2.0d";
          exit;








mysqli_close($conn); 

?>