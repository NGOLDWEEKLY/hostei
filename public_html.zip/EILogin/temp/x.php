<?php
  $root = $_SERVER['DOCUMENT_ROOT'];
include_once($root . "/EILogin/swift/lib/swift_required.php");
if(!@include_once($root . "/EILogin/swift/lib/swift_required.php")) {
    echo "Unable to load configuration file.";
}

try {
  $root = $_SERVER['DOCUMENT_ROOT'];
include_once($root . "/EILogin/swift/lib/swift_required.php");

$transport = Swift_SmtpTransport::newInstance('aspmx.l.google.com', 25)
  ->setUsername('hosteiappservices@gmail.com')
  ->setPassword('Uo02ovov36tb,[');

$mailer = Swift_Mailer::newInstance($transport);

$message = Swift_Message::newInstance('Test Subject')
  ->setFrom(array('hosteiappservices@gmail.com' => 'hostei'))
  ->setTo(array('ngoldweekly@gmail.com'))
  ->setBody('This is a test mail.');

$result = $mailer->send($message);



} catch (ErrorException $ex) {
    echo "Unable to load configuration file.";
    // you can exit or die here if you prefer - also you can log your error,
    // or any other steps you wish to take
}


$inc = 'path/to/my/include/file.php';

if (file_exists($inc) && is_readable($inc)) {

    include $inc;

} else {

    throw new Exception('Include file does not exists or is not readable.');
}
?>
