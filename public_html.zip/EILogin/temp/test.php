<?php
  
$to      = $md;
$subject = 'Last step to claim your EI account.';
$message = '<html>
<head>
<style>
@media  (max-width: 899px){
body{
    background: #f8f8f8;
    font-family: Arial,"Quicksand",微軟正黑體, "Microsoft Jhenghei", sans-serif;
    top: 0;
    border: 0;
    margin: 0;    overflow-x: hidden;
}



#logo, #bar,#lang{
    display: inline-block;
}
#logo-detail{
    font-family: Arial,"Quicksand",微軟正黑體, "Microsoft Jhenghei", sans-serif;
    top: 0;
        color: #8d8d8d;
    margin: 0;
    margin-top: -20px;

    text-align: center;

    font-size: 0.7em;    letter-spacing: 2px;
}
.logo{
    width: 100%;
    text-align: center;
    
    
    height: 200px;
}
.logo-title{
    
    display: inline-block;
     cursor:pointer;
    margin-top: 25px;
    transition:ease 0.6s;
}
.svg-holder{
    background-image: url(http://www.hostei.com/img/old-man-head.svg);
    background-position: center center;
    background-repeat: no-repeat;
    width: 200px;
    height: 200px;
    border-radius: 50%;
    
    position: absolute;
    z-index: 999;
    background-size: auto 180px;
    margin-left: 8px;
    
    transition: ease 0.6s;
    margin-top: -20px;

}
.holder{
	    box-shadow: 2px 2px 11px #d0d0d0;
}
.header-background{
        position: absolute;
    z-index: -9999;
    background: white;
    height: 200px;
    top: 0px;
    left: 0;
    right: 0;
    
    border-right: none;
    
}

#php-echo{
    margin-top: 80px;
text-align:center;
    
    
}

#echo-console {
    width: 60%;
    text-align: center;
    margin: auto;
    color: #787878;
    line-height: 25px;
	
    font-size: 14px;
}
#echo-verf button {
    width: 60%;
    max-width: 500px;
    height: 65px;
    font-size: 26px;
    background: white;
    color: #787878;
    cursor: pointer;
    border-radius: 50px;
    border: none;
    outline: none;
    margin-top: 20px;
    box-shadow: 1px 2px 3px #d0d0d0;
	font-weight:bold;
}		#echo-verf button:hover{
			background:#fff;
			}
#echo-verf button:active{
        background: linear-gradient(#e1e1e1,#f1f1f1);
    
}

h1{
    
    line-height: 44px;
    font-size: 35px;
	
    
}    
.echo-cancel a{
    margin-top: 20px;
    line-height: 50px;
    font-size: 15px;
    text-decoration: none;
    color: #a1a1a1;
}

 
}
@media screen and (min-width: 900px) {
body{
	
    background: #f8f8f8;
    font-family: Arial,"Quicksand",微軟正黑體, "Microsoft Jhenghei", sans-serif;
    top: 0;
    border: 0;
    margin: 0;    overflow-x: hidden;
}

#logo, #bar,#lang{
    display: inline-block;
}
#logo-detail{
    font-family: Arial,"Quicksand",微軟正黑體, "Microsoft Jhenghei", sans-serif;
    top: 0;
        color: #8d8d8d;
    margin: 0;
    margin-top: -20px;

    text-align: center;

    font-size: 0.7em;    letter-spacing: 2px;
}
.logo{
    width: 100%;
    text-align: center;
    
    
    height: 200px;
}
.logo-title{
    
    display: inline-block;
    margin-top: 25px;
    cursor:pointer;
    transition:ease 0.6s;
}
.svg-holder{
    background-image: url(http://www.hostei.com/img/old-man-head.svg);
    background-position: center center;
    background-repeat: no-repeat;
    width: 200px;
    height: 200px;
    border-radius: 50%;
    
    position: absolute;
    z-index: 999;
    background-size: auto 180px;
    margin-left: 8px;
    
    transition: ease 0.6s;
    margin-top: -20px;

}

.header-background{
        position: absolute;
    z-index: -9999;
    background: white;
    height: 200px;
    top: 0px;
    left: 0;
    right: 0;
    
    
}
.holder{
	    box-shadow: 2px 2px 11px #d0d0d0;
}
#php-echo{
    margin-top: 80px;
text-align:center;
    
    line-height: 30px;
    
}
h21{
	
    line-height: 30px;}
#echo-console {
    width: 60%;
    text-align: center;
    margin: auto;
    color: #787878;
    line-height: 25px;
    font-size: 14px;
}
#echo-verf button {
    width: 60%;
    max-width: 500px;
    height: 65px;
    font-size: 26px;
    background: white;
    color: #787878;
    cursor: pointer;
    border-radius: 50px;
    border: none;
    outline: none;
    margin-top: 20px;
    box-shadow: 1px 2px 3px #d0d0d0;
		font-weight:bold;
}		#echo-verf button:hover{
			background:#fff;
			}
		
#echo-verf button:active{
        background: linear-gradient(#e1e1e1,#f1f1f1);
    
}


h1{
    
    font-size: 35px;
}

.echo-cancel a{
    margin-top: 20px;
    line-height: 50px;
    font-size: 15px;
    text-decoration: none;
    color: #a1a1a1;
}



}

</style>
 <link rel="shortcut icon" href="http://www.hostei.com/img/favicon.png?v=3">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
<meta name="viewport" content="width=device-width">
<meta name="google-site-verification" content="XwHDAaem5TzpQQif796pOcH4hZcEqC2Yqz5f2IGHRmQ">
<title>host EI -Email Verification</title>

</head>
<body>
<div class="holder">
    <div class="header-background"></div>
<div class="header" id="header">
<div class="logo" id="logo"><a href="http://www.hostei.com" target="_blank">
<div class="logo-title">
<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/" x="0px" y="0px" width="221px" height="114.5px" viewBox="0 0 471 114.5" style="overflow:scroll;enable-background:new 0 0 471 114.5;" xml:space="preserve">
<style type="text/css">
	.st0{fill:#d0d0d0;}
	.st1{fill:#d0d0d0;}
.logo-title  svg:hover .st0,.logo-title  svg:hover .st1{fill:#b3b3b3;}
</style>

<defs>
</defs>
<g id="XMLID_64_">
	<g id="XMLID_77_">
		<rect id="XMLID_80_" x="404.9" y="9.8" class="st0" width="66.1" height="24.1"></rect>
		<path id="XMLID_78_" class="st0" d="M407.3,30.4v-17h61.5v17H407.3z"></path>
	</g>
	<g id="XMLID_73_">
		<polygon id="XMLID_76_" points="359.6,99.2 359.6,0 426,0 426,20.8 383.3,20.8 383.3,38.7 417.6,38.7 417.6,59.1 383.3,59.1 
			383.3,77.8 426.6,77.8 426.6,99.2 		"></polygon>
		<path id="XMLID_74_" d="M423.1,95.7h-59.9V3.5h59.3v13.7h-42.7v25h34.3v13.4h-34.3v25.8h43.3V95.7z"></path>
	</g>
	<g id="XMLID_69_">
		<rect id="XMLID_72_" x="426.6" y="11.3" class="st0" width="24.1" height="101.6"></rect>
		<path id="XMLID_70_" class="st0" d="M447.2,109.3h-17V14.8h17V109.3z"></path>
	</g>
	<g id="XMLID_65_">
		<rect id="XMLID_68_" x="404.9" y="90.4" class="st0" width="66.1" height="24.1"></rect>
		<path id="XMLID_66_" class="st0" d="M407.3,110.9v-17h61.5v17H407.3z"></path>
	</g>
</g>
<g id="XMLID_48_">
	<polygon id="XMLID_63_" class="st1" points="49.6,96.5 49.6,58.2 22.5,58.2 22.5,96.5 0,96.5 0,1.7 22.5,1.7 22.5,38 49.6,38 
		49.6,1.7 72.1,1.7 72.1,96.5 	"></polygon>
	<path id="XMLID_61_" class="st1" d="M68.8,93.2H52.9V54.9H19.2v38.3H3.3V5h15.9v36.3h33.7V5h15.9V93.2z"></path>
	<path id="XMLID_58_" class="st1" d="M120.7,97.9c-12.8,0-22.9-4.9-30-14.5c-6.9-9.3-10.4-21-10.4-34.5c0-13.6,3.7-25.1,11.1-34.3
		c7.6-9.4,17.7-14.2,30-14.2c12.5,0,22.5,4.8,29.8,14.2c7.1,9.2,10.7,20.8,10.7,34.4c0,14.3-3.7,26.1-11.1,35.1
		C143.2,93.3,133.1,97.9,120.7,97.9z M121.1,19.8c-4.2,0-17.1,0-17.1,29.6c0,10,1.6,17.5,4.7,22.4c2.8,4.5,6.8,6.7,12.1,6.7
		c4.7,0,8.7-1.9,12-5.9c3.4-4.1,5.2-12.1,5.2-23.7c0-9.5-1.5-17-4.5-22.2C130.8,22,126.9,19.8,121.1,19.8z"></path>
	<path id="XMLID_55_" class="st1" d="M120.7,94.6c-11.7,0-20.8-4.4-27.4-13.2s-9.8-19.6-9.8-32.6c0-12.8,3.5-23.6,10.4-32.2
		c6.9-8.6,16.1-13,27.5-13c11.5,0,20.5,4.3,27.2,13c6.7,8.6,10,19.4,10,32.4c0,13.6-3.5,24.6-10.4,33
		C141.3,90.4,132.1,94.6,120.7,94.6z M120.8,81.8c5.7,0,10.6-2.4,14.5-7.1c4-4.7,5.9-13.3,5.9-25.8c0-10.1-1.6-18.1-4.9-23.8
		c-3.3-5.8-8.4-8.6-15.3-8.6c-13.6,0-20.4,11-20.4,32.9c0,10.6,1.7,18.7,5.2,24.2C109.4,79.1,114.3,81.8,120.8,81.8z"></path>
	<path id="XMLID_54_" class="st1" d="M200.2,97.9c-9.3,0-17.6-2-24.6-5.9c-7.3-4.1-12.3-10.5-14.7-19.1l-0.9-3.4l22.1-4.7l0.7,3.2
		c1,4.5,3.9,10.5,18.1,10.5c4.9,0,8.6-0.9,11.1-2.7c2.2-1.6,3.2-3.4,3.2-5.7c0-1.8-0.5-3.3-1.5-4.8c-0.5-0.8-2.1-2.2-6.9-3.5
		l-16.9-4.4c-6.2-1.6-10.7-3.5-13.9-5.6c-3.2-2.2-5.8-5.4-7.7-9.4c-1.9-3.9-2.8-8.2-2.8-12.6c0-8.9,3.4-16.1,10-21.5
		c6.4-5.2,14.7-7.9,24.6-7.9c8.1,0,15.5,1.8,21.9,5.4c6.8,3.8,11.1,9.2,13,16.1l0.9,3.3l-21.3,5.3l-1-2.8c-1.2-3.3-3.8-7.8-13.2-7.8
		c-4.2,0-7.3,0.8-9.3,2.4c-1.8,1.4-2.7,3.1-2.7,5.3c0,1.2,0,5,9.8,7.4l15,3.7c10,2.5,16.6,6.3,20.2,11.4c3.5,5,5.2,10.6,5.2,16.7
		c0,9.7-3.7,17.5-11.1,23.1C220.4,95.2,211.2,97.9,200.2,97.9z"></path>
	<path id="XMLID_52_" class="st1" d="M164.1,72l15.4-3.3c1.9,8.7,9,13.1,21.3,13.1c5.6,0,10-1.1,13-3.4c3-2.2,4.6-5,4.6-8.3
		c0-2.4-0.7-4.6-2.1-6.7c-1.4-2-4.3-3.7-8.9-4.8l-16.9-4.4c-5.8-1.5-10-3.2-12.8-5.1c-2.8-1.9-5-4.6-6.6-8.1
		c-1.7-3.5-2.5-7.2-2.5-11.2c0-7.9,2.9-14.2,8.8-19c5.9-4.8,13.4-7.1,22.5-7.1c7.6,0,14.4,1.7,20.3,5c6,3.3,9.8,8,11.4,14.1
		l-15.1,3.7c-2.3-6.7-7.8-10-16.3-10c-5,0-8.7,1-11.3,3.1c-2.6,2.1-3.9,4.7-3.9,7.9c0,5,4.1,8.6,12.3,10.6l15,3.7
		c9.1,2.3,15.2,5.7,18.3,10.1c3.1,4.5,4.7,9.4,4.7,14.8c0,8.7-3.3,15.5-9.8,20.5c-6.5,5-15,7.5-25.4,7.5c-8.7,0-16.4-1.8-23-5.5
		C170.6,85.4,166.3,79.7,164.1,72z"></path>
	<polygon id="XMLID_51_" class="st1" points="259.4,96.5 259.4,22 236,22 236,1.7 306.5,1.7 306.5,22 283.1,22 283.1,96.5 	"></polygon>
	<path id="XMLID_49_" class="st1" d="M279.8,93.2h-17.1V18.7h-23.5V5h64v13.6h-23.5V93.2z"></path>
</g>
</svg>

<p id="logo-detail">EXPERIENCING &amp; INTELLIGENCE</p></div></a></div>


</div></div>
<div id="php-echo">
<div id="echo-console" class="echo-console"><h1>Email Verification</h1><p>Hey there, you have requested for an EI Account. Please click the button below to verify your identity. <br>(Not you? Just ignore this mail and delete it.)</p></div>
<div id="echo-verf">
<a href="http://www.hostei.com/EILogin/temp/ver?md="><button>Verify Account</button></a>

</div>
<div id="echo-cancel" class="echo-cancel">
    <a href="http://www.hostei.com/">Back to home</a>
    </div>
    </div></body></html>';
$headers = 'From: "Host EI" <noreply@hostei.com>' . "\r\n" .
    'Reply-To: "Host EI" <support@hostei.ga>' . "\r\n" .
    'MIME-Version: 1.0' ."\r\n" .
        'Content-Type: text/html' ."\r\n"     ;


mail($to, $subject, $message, $headers);





?>