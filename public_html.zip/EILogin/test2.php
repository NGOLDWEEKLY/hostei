
    <?php
// Get connection
$servername = "localhost";
$username = "id2188560_hostei";
$password = "Uo02ovov36tb,[";
$dbname = "id2188560_hostei";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    echo "Connection failed. Please try again later.";
    echo "<br>";
}


$admm = "INSERT INTO feed_dt (lv)
VALUES ('John')";

if (mysqli_query($conn, $admm)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $admm . "<br>" . mysqli_error($conn);
}


$feed = "INSERT INTO feed_dt (lv) 
VALUES ('8')";



if(mysqli_query($conn,$feed)) {
   echo  "can";
}else{
    echo  "cannot";
 

}

mysqli_close($conn); 

?>