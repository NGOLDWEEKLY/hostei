<?php
// Get connection
$servername = "localhost";
$username = "id2188560_hostei";
$password = "Uo02ovov36tb,[";
$dbname = "id2188560_hostei";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    echo "Connection failed. Please try again later.";
    echo "<br>";
}
$md = $_REQUEST["md"];

$admt = "SELECT * from ei_host_inf where ei_md ='$md'";
 if ($result=mysqli_query($conn,$admt))
  {
   if(mysqli_num_rows($result) > 0)
    {
      echo "0";
   
    }
  else
      echo "1";



  }
else
    echo "Timeout.";








mysqli_close($conn); 

?>