<html>
<head>
 <link rel="shortcut icon" href="http://www.hostei.com/img/favicon.png?v=3">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
<meta name="viewport" content="width=device-width">
<meta name="google-site-verification" content="XwHDAaem5TzpQQif796pOcH4hZcEqC2Yqz5f2IGHRmQ">
<title>host EI -Email Verification</title>
 <link rel="stylesheet" type="text/css" href="local.css">
</head>
<body>
<div id="php-echo">
<div id="echo-console" class="echo-console"><h1>Email Verification</h1><p>Hey there, you have requested for an EI Account. We have sent a mail to your email provided. Please check your mailbox. <br>(Not received? Check your spam mailbox or <a href="../services/report/signup-error">send error.</a>)</p></div>
<div id="echo-verf">
<div class="img-smp">
</div>
</div>
<div id="echo-cancel" class="echo-cancel">
    <a href="http://www.hostei.com/">Back to home</a>
    </div>
    </div></body></html>