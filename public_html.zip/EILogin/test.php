<?php
$servername = "localhost";
$username = "id2188560_hostei";
$password = "Uo02ovov36tb,[";
$dbname = "id2188560_hostei";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$admm = "INSERT INTO try (try)
VALUES ('John')";

if (mysqli_query($conn, $admm)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $admm . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>