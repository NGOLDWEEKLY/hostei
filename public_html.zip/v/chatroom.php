<!DOCTYPE HTML>
<html>
    <head>
        <style>
        #chat {
            background:#e2e2e2;
            border-style:none;
    padding-left: 10px;
    height: 30px;
    width: 200px;
        }

#btnsubmit {
    background: #ffffff;
    margin-left: 2px;
    border-style: none;
    width: 30px;
    font-size: 12px;
    height: 32px;
    color:#438a63;
    cursor:pointer;
    transition: ease 0.4s;
            }
            #btnsubmit:hover{
                background:#438a63;
                color:white;
    border-style: solid;
    border-width:1px;
                border-color:white;
            }
            
        </style>
<script>
var auto_refresh = setInterval(function() { submitform(); }, 20000);

function submitform()
{ var data = document.getElementById('chat').value;
    if(data == null || data == undefined || data == "")
  { return;}

else{var form = document.getElementById('form');

     form.submit();
      }
      
  }
     
function setCookie(cname,cvalue,exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
  
    window.onload = function(){
        var user=getCookie("chatuser");
	    if (user !== "") {
document.getElementById('pg1').innerHTML="";
document.getElementById('pg2').style.display="block";
document.getElementById('input').innerHTML = "<input type='hidden' name='user' id='user'/><input type='text' name='chat' id='chat'/><input type='submit' id='btnsubmit' value='&#10004;'/>";

            document.getElementById('user').value = user;
		}
	   
    }
function set(){
var x =document.getElementById('name').value;
           setCookie("chatuser", x, 30);  
             
document.getElementById('pg1').innerHTML="";
document.getElementById('pg2').style.display="block";
document.getElementById('input').innerHTML = "<input type='hidden' name='user' id='user'/><input type='text' name='chat' id='chat' /><input type='submit' id='btnsubmit'  value='&#10004;'/>";

    document.getElementById('user').value = x;
}
</script>
</head>
<body>
<div id="pg1" style="text-align:center;font-family:Microsoft YaHei;color:white;">
<input placeholder="输入名字以加入聊天" type="name" style="margin-top:10px;width:200px;border-style:none;background:#e1e1e1;height:30px;text-align:center" id="name"/><br><button onclick="set()" style="background:white;border-style:solid;font-family:Microsoft YaHei;font-weight:bold;width:203px;height:30px;letter-spacing:3px;border-color:white;
                color:#438a63;">继续</button></div>
<div id="pg2" style="display:none;">

    <span id="test12" name="test12"></span>

<form id="form" name="form" method="post" action="chatroomin.php"  style="
    margin: auto;
    width: 250px;">
    <span id="input" style="
    margin: auto;
    width: 250px;
"></span>
</form></div></body>
</html>