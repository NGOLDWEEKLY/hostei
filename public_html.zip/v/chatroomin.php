<meta http-equiv="refresh" 
   content="0; url=http://shef.herobo.com/chatroom/chatroom.php">
    <?php
// Get connection
$servername = "localhost";
$username = "id2188560_ngold";
$password = "qwertyqwerty";
$dbname = "id2188560_chatroom";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    echo "Connection failed. Please try again later.";
    echo "<br>";
}
$user = $_POST['user'];
$chat = $_POST['chat'];
$sql = "INSERT INTO Chats (user, chat)
VALUES ('$user','$chat')";

if(mysqli_query($conn, $sql)) {
 
}else{
    echo "Error: " . $sqli . "<br>" . mysqli_error($conn);
    
}

mysqli_close($conn); 

?>