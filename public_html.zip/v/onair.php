<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="refresh" content="1">
        <script>

function autoScrolling() {
   window.scrollTo(0,document.body.scrollHeight);
}
       </script>
        <style>
       
        body {
      font-family:Arial,'Times New Roman','Microsoft YaHei',SimHei; 
background:#b07b00;
        }
        p{
           font-size:10px; 
            color:#b88900;
        }
        h3{
            color:#530101;
           margin-top:-5px; 
           -ms-word-break: break-all;
    word-break: break-all;

    font-size: 20px;
     word-break: break-word;

    -webkit-hyphens: auto;
       -moz-hyphens: auto;
        -ms-hyphens: auto;
            hyphens: auto;

    padding-right: 15px;
        }
        .you{  
            background:#f1f1f1;
            padding-left:15px;
            border-radius:15px;
            padding-top:0.4px;
            padding-bottom:0.2px;
            margin-bottom:10px;
              width: 120px;
   -moz-border-radius:    10px;
   -webkit-border-radius: 10px;
   border-radius:         10px;
        }

        </style>
        </head>
<body>

<?php
// Get connection
$servername = "localhost";
$username = "id2188560_ngold";
$password = "qwertyqwerty";
$dbname = "id2188560_chatroom";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    echo "Connection failed. Please try again later.";
    echo "<br>";
}

$sql = "SELECT user, chat FROM Chats";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo "<div class=you><p>" . $row["user"]. " </p><h3> " . $row["chat"]. "</h3></div>";
    }
} else {
    echo "<p>";
    echo "开始聊天吧！";
    echo "</p>";
}

mysqli_close($conn);
?> 

<div id="div">
</div>
</body>