<?php
// Get connection
$servername = "localhost";
$username = "id2188560_ngold";
$password = "qwertyqwerty";
$dbname = "id2188560_chatroom";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    echo "Connection failed. Please try again later.";
    echo "<br>";
}else{
    echo "Connected.";
    echo "<br>";
}


$email = $_POST['email'];
$password = $_POST['password'];
$email = stripcslashes($email);
$password = stripcslashes($password);
$email = mysql_real_escape_string($email);
$password = mysql_real_escape_string($password);
mysql_connect("localhost", "id2188560_ngold","qwertyqwerty");
mysql_select_db("id2188560_chatroom");
$result = mysqli_query("select * from Users where email='$email' and password='$password'")
or die("Failed to query database" .mysqli_error());
$row = mysqli_fetch_array($result);
if($row['email'] == $email && $row['password'] == $password ){ 
    echo "Login successful redirecting";
}else{
    echo "username does not exist.";}
mysqli_close($conn); 

?>