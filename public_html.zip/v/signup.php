<?php
// Get connection
$servername = "localhost";
$username = "id2188560_ngold";
$password = "qwertyqwerty";
$dbname = "id2188560_chatroom";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    echo "Connection failed. Please try again later.";
    echo "<br>";
}else{
    echo "Connected.";
    echo "<br>";
}
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$sql = "INSERT INTO Users (name, email, password)
VALUES ('$name','$email','$password')";

if(mysqli_query($conn, $sql)) {
    $last_id = mysqli_insert_id($conn);
    echo $last_id;
    echo "<br>";
    echo "You've done your information.";
    echo "<br>";
}else{
    echo "Error: " . $sqli . "<br>" . mysqli_error($conn);
    
}

mysqli_close($conn); 

?>