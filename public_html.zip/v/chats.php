<?php
$user = $_REQUEST['user'];
$chat = $_REQUEST['chat'];

// Get connection
$servername = "localhost";
$username = "id2188560_ngold";
$password = "qwertyqwerty";
$dbname = "id2188560_chatroom";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    echo "Connection failed. Please try again later.";
    echo "<br>";
}
mysqli_query("INSERT INTO Chats (user, chat)
VALUES ('$user','$chat')");

$sql = "SELECT user, chat FROM Chats";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo "<div class=you><p>" . $row["user"]. " </p><h3> " . $row["chat"]. "</h3></div>";
    }
} else {
    echo "<p>";
    echo "开始聊天吧！";
    echo "</p>";
}

mysqli_close($conn);
?> 