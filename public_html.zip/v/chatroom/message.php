<?php
// Get connection
$servername = "localhost";
$username = "id2188560_ngold";
$password = "qwertyqwerty";
$dbname = "id2188560_chatroom";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    echo "Connection failed. Please try again later.";
    exit;
}
$id = $_REQUEST["id"];


$f = "SELECT* FROM Chat_rr
ORDER BY id DESC
LIMIT 1" ;
$result=mysqli_query($conn, $f);
if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $nid= $row[id];
        $id = $nid- $id;
  
    }
}



$sql = "(SELECT username, chat FROM Chat_rr
ORDER BY id DESC
LIMIT $id )" ;


$result = mysqli_query($conn,$sql);


if (mysqli_num_rows($result) > 0) {
    // output data of each row
    
    

    while($row = mysqli_fetch_assoc($result)) {
        echo "<div class='you ".$row["username"]."'><p class='" . $row["username"]. "'>" . $row["username"]. " </p><h3> " . $row["chat"]. "</h3></div>";
    }
} 


mysqli_close($conn);
?>