
    <?php
// Get connection
$servername = "localhost";
$username = "id2188560_ngold";
$password = "qwertyqwerty";
$dbname = "id2188560_chatroom";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    echo "Connection failed. Please try again later.";
    echo "<br>";
}
$username = $_REQUEST["user"];
$chat = $_REQUEST["chat"];
$sql = "INSERT INTO Chat_rr (username, chat)
VALUES ('$username','$chat')";

if(mysqli_query($conn, $sql)) {
 
}else{
    echo "Error: " . $sqli . "<br>" . mysqli_error($conn);
    
}

mysqli_close($conn); 

?>
<!DOCTYPE HTML>
<html>
<body>
        
        </body>
</html>