
        <input type='hidden' name='user' id='user' /><input type='text' name='chat' id='chat' onfocus='autoScrolling()' onkeyup='myfunction(this.value)' placeholder='输入消息...' autofocus autocomplete='off'/></span>
