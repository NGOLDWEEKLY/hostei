<meta http-equiv="refresh" 
   content="0; url=http://www.hostei.com/v/chatroom"><meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=yes">
   
        <style>
        input:focus,
select:focus,
textarea:focus,
button:focus {
    outline: none;
}
        #put{
            margin-top:0px;
        }
        #room::-webkit-scrollbar-track
{
	border-radius: 10px;    background-color: rgba(0, 0, 0, 0.41);
}
#room {
background: #b07b00;
    
}
#room::-webkit-scrollbar
{
	width: 12px;
}

#room::-webkit-scrollbar-thumb
{
	border-radius: 10px;    background-color: rgba(0, 0, 0, 0.41);
}

        body{
        margin:auto;
        background:#ffb200;
        font-family:Microsoft Yahei;
        position: absolute;
top: 50%;
left: 50%;
transform: translateX(-50%) translateY(-50%);
        
    }
        #chat {
            background:#e2e2e2;
            border-style:none;
    padding-left: 10px;
    height: 60px;
    width: 260px;
        }

#btnsubmit {
    background: #ffffff;
    margin-left: 2px;
    border-style: none;
    width: 30px;
    font-size: 12px;
    height: 32px;
    color:#ffb200;
    cursor:pointer;
    transition: ease 0.4s;
            }
            #btnsubmit:hover{
        background:#ffb200;
                color:white;
    border-style: solid;
    border-width:1px;
                border-color:white;
            }
            
        </style>
<script>



function setCookie(cname,cvalue,exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
    window.onload = function(){
                var user=getCookie("chatuser");
        var i;
        var las = "you " +user;
var name =  document.getElementsByClassName(las);
for (i = 0; i < name.length; i++) { 
  document.getElementsByClassName(las)[i].style.background = "#fffa78";
  document.getElementsByClassName(las)[i].style.marginLeft = "80px";
}
	    if (user == "") {
document.getElementById('pg2').style.display="none";
document.getElementById('pg1').style.display="block";
        
		} else if(user !== ""){
		    
            document.getElementById('user').value = user;
            document.getElementById('user2').value = user;
                    autoScrolling();
                    

		    
		}
	     
        var stra = document.getElementsByTagName("h3");
        var i;
for (i = 0; i < stra.length; i++) {
    var b = stra[i].innerHTML;
 var a = b.includes('png');
 var d = b.includes('jpg');
 var e = b.includes('jpeg');
 var g = b.includes('gif');
        if(a == true || d == true|| e == true|| g == true){
           var c= b.replace(/\s/g, '')
        stra[i].innerHTML = "<img src='uploads/"+ c + "' width='100px;'>";
        autoScrolling();
    }   
}
    }
    
    function myfunction(x){
        
var n = x.includes("fuck");
        if(n == true){
            document.getElementById('chat').value = 'I swear, but I wont say nonsense anymore.';
        }
       var o = x.includes("shit");
        if(o == true){
            document.getElementById('chat').value = 'I swear, but I wont say nonsense anymore.';
        }
       var m = x.includes("他妈");
        if(m == true){
            document.getElementById('chat').value = '我发誓不再爆粗了。';
        }
       var am = x.includes("鸡白");
        if(am == true){
            document.getElementById('chat').value = '我发誓不再爆粗了。';
        }
       var abm = x.includes("walao");
        if(abm == true){
            document.getElementById('chat').value = '我发誓不再爆粗了。';
        }
       var acm = x.includes("哇老");
        if(acm == true){
            document.getElementById('chat').value = '我发誓不再爆粗了。';
        }
       var acmn = x.includes("哇佬");
        if(acmn == true){
            document.getElementById('chat').value = '我发誓不再爆粗了。';
        }
        
    }
    function refresh()
    {
        var user = getCookie("chatuser");
         
	    if (user !== "") {
        var y= document.getElementById('room').scrollHeight;
        var z= document.getElementById('room').scrollTop;
       
             
        var data = document.getElementById('chat').value;
        var pic = document.getElementById('picture').value;
 if ((data == "" || data == null || data == undefined) && 500+z >= y && pic ==""){
             location.reload();        
        }
        
        
    }
        
    }
    
 setInterval(refresh , 4000); 
        
function set(){
var x =document.getElementById('name').value;
           setCookie("chatuser", x, 30);  
             
document.getElementById('pg1').innerHTML="";
document.getElementById('pg2').style.display="block";
    document.getElementById('user').value = x;
                 location.reload();        
}
</script>
<script>

function autoScrolling() {
        var divFirst = document.getElementById("room");
    divFirst.scrollTop = divFirst.scrollHeight;
document.getElementById("chat").focus(); 
}
        </script>
        <style>
    
        body {
      font-family:Arial,'Times New Roman','Microsoft YaHei',SimHei; 

        }
        p{
           font-size:10px; 
            color:#b88900;
        }
        h3{
            color:#530101;
           margin-top:-5px; 
           -ms-word-break: break-all;
    word-break: break-all;

    font-size: 20px;
     word-break: break-word;

    -webkit-hyphens: auto;
       -moz-hyphens: auto;
        -ms-hyphens: auto;
            hyphens: auto;

    padding-right: 15px;
        }
        .you{  
            background:#f1f1f1;
            padding-left:15px;
            border-radius:15px;
            padding-top:0.4px;
            padding-bottom:0.2px;
            margin-bottom:10px;
              width: 120px;
   -moz-border-radius:    10px;
   -webkit-border-radius: 10px;
   border-radius:         10px;
   animation:show 0.5s;
        }
      @keyframes show {
          0%{opacity:0;}
          99%{opacity:0;}
          100%{opacity:1;}
          
      }
        </style>
   <script>
   <?php
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 10000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
?></script>
<body><div style="    width: 305px;
    background: #795104;
    margin: auto;
    height: 100px;"><p style="    padding-top: 20px;letter-spacing:6px;font-size:40px;text-align:center;font-weight:bold;color:white;">E I聊天室</p></div>
 <div id="room"  style="  margin: auto;
    clear: both;
    padding: 1px 20px;
    overflow-y: scroll;
    max-height: 300px;
    width: 230px;
    overflow-x: hidden;
    height: 300px;">
<span id="scroll"></span></div>

<div id="div">
</div>
<div ><div id="pg2" style="display:block;">

    <span id="test12" name="test12"></span>

<form id="form" name="form" method="post" action="chatroom.php"  style="
    margin: auto;    width: 270px;">
    <span id="input" style="
    margin: auto;
    width: 250px;
"><span id="input"><input type='hidden' name='user' id='user'/><div id='put'><input type='text' name='chat' id='chat' /></span></div>
</form></div></div></body>


    <?php
// Get connection
$servername = "localhost";
$username = "id2188560_ngold";
$password = "qwertyqwerty";
$dbname = "id2188560_chatroom";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    echo "Connection failed. Please try again later.";
    echo "<br>";
}
$user = $_POST['user2'];
$chat = $_POST['picture'];
$sql = "INSERT INTO Chats (user, chat)
VALUES ('$user','$chat')";

if(mysqli_query($conn, $sql)) {
 
}else{
    echo "Error: " . $sqli . "<br>" . mysqli_error($conn);
    
}

mysqli_close($conn); 

?>