<?php
// Get connection
$servername = "localhost";
$username = "id2188560_ngold";
$password = "qwertyqwerty";
$dbname = "id2188560_chatroom";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    echo "Connection failed. Please try again later.";
    echo "<br>";
}else{
    echo "Connected.";
    echo "<br>";
}

$sql = "UPDATE Users SET password='zxcvbzxcvb' WHERE id=2";

if (mysqli_query($conn, $sql)) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . mysqli_error($conn);
}

mysqli_close($conn); 

?>