<?php
// Get connection
$servername = "localhost";
$username = "id2188560_ngold";
$password = "qwertyqwerty";
$dbname = "id2188560_chatroom";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    echo "Connection failed. Please try again later.";
    echo "<br>";
}else{
    echo "Connected.";
    echo "<br>";
}

// Create table
$sql = "CREATE TABLE Users (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(30) NOT NULL,
    email VARCHAR(50),
    password VARCHAR(30) NOT NULL,
    reg_date TIMESTAMP
    
    )";
    
if(mysqli_query($conn,$sql)){
    echo "apple,";
    echo "<br>";
    echo "You've signed up. Now let's sign in.";
    echo "<br>";
}else{
    echo "Error creating table: " . mysqli_error($conn);
}


mysqli_close($conn);
?>